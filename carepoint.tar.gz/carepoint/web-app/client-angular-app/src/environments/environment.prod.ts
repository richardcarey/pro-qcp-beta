export const environment = {
  production: true,
  ServiceUrl: '',
  credentail: '',
};
