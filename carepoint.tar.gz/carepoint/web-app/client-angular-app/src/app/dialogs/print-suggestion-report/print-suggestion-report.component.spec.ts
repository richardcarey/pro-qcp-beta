import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintSuggestionReportComponent } from './print-suggestion-report.component';

describe('PrintSuggestionReportComponent', () => {
  let component: PrintSuggestionReportComponent;
  let fixture: ComponentFixture<PrintSuggestionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintSuggestionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintSuggestionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
