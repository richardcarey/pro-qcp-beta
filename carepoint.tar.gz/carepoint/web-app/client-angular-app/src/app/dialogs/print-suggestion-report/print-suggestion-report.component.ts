import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';
import { NotificationService } from 'src/app/services/notification.service';
import { LoadingPopupComponent } from '../loading-popup/loading-popup.component';

@Component({
  selector: 'app-print-suggestion-report',
  templateUrl: './print-suggestion-report.component.html',
  styleUrls: ['./print-suggestion-report.component.scss']
})
export class PrintSuggestionReportComponent implements OnInit {

  isPrintOption = false;
  invalidForm = false;
  summary:string;
  reason:string;
  cantSaveRevision = false;
  cantSaveRevisionRoles = ["administrator","customer","lab_tech", "lab_director"];
  isLoading: boolean = false;
  constructor(
    @Inject(MAT_DIALOG_DATA) public iqcpData: any,
    private dialog: MatDialog,
    private apiService: ApiService, 
    private route: ActivatedRoute, 
    private notifyService : NotificationService,
    private _DataService: DataService
    ) { }

  ngOnInit(): void {
    let currentUserRole = this._DataService.currentUserRole;
    this.cantSaveRevision = this.cantSaveRevisionRoles.indexOf(currentUserRole) !== -1;
  }
  radioChange(value){
    this.isPrintOption = value;
  }

  submitPrintForm(printAndSave){
    this.isLoading = true;
    
    if(!printAndSave){
      this.print();
    } else {
      this.saveRevision(printAndSave);
    }
  }

  print() {
    const loading = this.dialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your report is being prepared...'
      },
      width: '300px',
    });
    
    this.apiService.getPDFSuggestionReport(this.iqcpData.order_item_id).subscribe((res: any) => {
      if (res !== 'Invalid User') {
        const link = document.createElement('a');
        const base64PDF = res.pdfB64;
        link.href = 'data:application/pdf;base64,' + base64PDF;
        link.download = 'Suggestion-Report.pdf';
        link.click();
      }
      loading.close();
      setTimeout(() => {
        document.getElementById("revisionsModalClose").click();
        }, 500);
    });
  }

  saveRevision(printAndSave){
    if(printAndSave && !this.summary || printAndSave && !this.reason){
      this.invalidForm = true;
      this.isLoading = false;
      return;
    }
   
    this.createNewRevision(this.iqcpData.order_item_id, this.reason, this.summary, this.iqcpData.revision);
  }

  createNewRevision(order_item_id, reason, summary, revision){
    let postRequest = { 
      "id": '',
      "order_item_id": order_item_id,
      "reason": reason,
      "summary": summary,
      "filename": '',
      "base64": '',
      "revision": revision
  };
    this.apiService.createSuggestionReportRevision(postRequest).subscribe((res: any) => {
      if(res){
        postRequest.id = res;
        this.apiService.getPDFSuggestionReport(this.iqcpData.order_item_id).subscribe((pdf_res: any) => {
          console.log(pdf_res);
            postRequest.base64 = pdf_res.pdfB64;
            postRequest.filename = 'Suggestion-Report.pdf';
            this.apiService.updateSuggestionReportRevisionFile(postRequest).subscribe((res: any) => {
              setTimeout(() => {
                this.print();
             }, 1000);
            })
        });
        this.showToaster('Revision Saved!', 'Revisions')
        this.invalidForm = false;
      }
    
    });
  }

  showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }

}
