import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintQcpDialogComponent } from './print-qcp-dialog.component';

describe('PrintQcpDialogComponent', () => {
  let component: PrintQcpDialogComponent;
  let fixture: ComponentFixture<PrintQcpDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintQcpDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintQcpDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
