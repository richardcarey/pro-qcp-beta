import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-severity-info',
  templateUrl: './severity-info.component.html',
  styleUrls: ['./severity-info.component.scss']
})
export class SeverityInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
