import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeverityInfoComponent } from './severity-info.component';

describe('SeverityInfoComponent', () => {
  let component: SeverityInfoComponent;
  let fixture: ComponentFixture<SeverityInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeverityInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeverityInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
