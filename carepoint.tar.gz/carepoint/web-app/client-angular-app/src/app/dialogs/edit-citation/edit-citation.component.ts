import { Component, Inject, OnInit} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DataService } from './../../services/data.service';
import { AngularEditorConfig } from '@kolkov/angular-editor';
@Component({
  selector: 'app-edit-citation',
  templateUrl: './edit-citation.component.html',
  styleUrls: ['./edit-citation.component.scss']
})


export class EditCitationComponent implements OnInit {
  object:any = {};
  htmlContent;
  updatedQcp = false;

  editorConfig: AngularEditorConfig = {
    editable: true,
      spellcheck: true,
      height: 'auto',
      minHeight: '100',
      maxHeight: 'auto',
      width: 'auto',
      minWidth: '0',
      translate: 'yes',
      enableToolbar: true,
      showToolbar: true,
      placeholder: 'Enter text here...',
      defaultParagraphSeparator: '',
      defaultFontName: '',
      defaultFontSize: '',
      fonts: [
        {class: 'arial', name: 'Arial'},
        {class: 'times-new-roman', name: 'Times New Roman'},
        {class: 'calibri', name: 'Calibri'},
        {class: 'comic-sans-ms', name: 'Comic Sans MS'}
      ],
      customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      ['customClasses', 'insertImage', 'insertVideo', 'link', 'unlink','insertHorizontalRule','removeFormat','toggleEditorMode'],
    ]
  };

  ngOnInit(): void {
    this.object = this.data.object;
    this.object.citation = decodeURI(this.object.citation);
    this.htmlContent = this.object.citation;
  }

  constructor(@Inject(MAT_DIALOG_DATA) public data, private _DataService: DataService) { 
  }

  editQcpCitation() {
   this.object.citation = decodeURI(this.object.citation);
   this.object.citation = this.htmlContent;
   this._DataService.changeQcp(this.object);

  }
}
