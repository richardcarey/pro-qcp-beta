import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProbabilityInfoComponent } from './probability-info.component';

describe('ProbabilityInfoComponent', () => {
  let component: ProbabilityInfoComponent;
  let fixture: ComponentFixture<ProbabilityInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProbabilityInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProbabilityInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
