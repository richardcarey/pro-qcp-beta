import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-probability-info',
  templateUrl: './probability-info.component.html',
  styleUrls: ['./probability-info.component.scss']
})
export class ProbabilityInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
