export interface Qcp {
	QCP_ID: string,
	risk_id: string,
	Frequency: string,
	Criteria: string,
	Action: string,
	CAP_Citation: string,
	CAP_txt: string,
	TJC_Citation: string,
	CLIA_Citation: string,
	CLIA_txt: string,
	COLA_Citation: string,
	COLA_txt: string,
  Add_to_QCP_Table: boolean,
  current_practice: boolean,
  index_row: number
}