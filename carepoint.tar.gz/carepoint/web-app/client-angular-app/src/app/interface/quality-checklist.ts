export interface QualityChecklist {
    title: string;
    description: string;
    list?: string[];
    checked?: boolean;
}
