export interface AcceptabilityData {
    iqcp_module: number;
    uid: number,
    created: number,
    version: number,
    order_id: string,
    items:any []
  }
  