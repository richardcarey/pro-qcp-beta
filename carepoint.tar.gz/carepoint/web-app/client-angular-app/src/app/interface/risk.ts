import { Qcp } from './qcp'
export interface Risk {
	risk_id: number,
	severity: string,
	severity_options: string [],
	harm: string,
	harm_options: string [],
	description: string
	risk_present: boolean,
	typical_number_of_errors: number,
	recommended_probability: string,
	acceptance: string,
	iqcp_module: number,
	category: string,
	probability: string
	qcp: Qcp []
}
  