
export interface RiskAssessment {
  assessment_id: string;
  order_id: string;
  iqcp_module: string,
  active,
  fishbone: string,
  is_demo: string,
  manufacturer__c: string,
  test_system: string,
  Cartridge: string,
  matrix_id: string,
  analytes: string,
  assessment_name: string,
  version: number,
  Part_Number: string,
  price: string,
  uid: string,
  created: string,
  Product_group: string,
  status: string,
  Title: string,
  Display_Sort__c: string,
  string_token_replacement_values: any [],
  laboratory_director_name: string,
  laboratory_director_title: string,
  accrediting_agency: any [],
  wards: any [],
  risks: any [],
  quality_assessments: any,
  device: string,
  is_generic: string
}
  