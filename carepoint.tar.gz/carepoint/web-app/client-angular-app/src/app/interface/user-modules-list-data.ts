export interface UserModulesListData {
    order_number: number;
    identifier: string;
    department: string;
    manufacturer: string;
    device: string;
    part: string;
    version: string;
    expiration_date: string;
  }