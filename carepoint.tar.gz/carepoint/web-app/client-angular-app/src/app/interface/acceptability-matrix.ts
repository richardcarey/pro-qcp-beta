export interface AcceptabilityMatrix {
    probability: string;
    negligible: string;
    minor: string;
    serious: string;
    critical: string;
    catastrophic: string;
    iqcp_module: number;
}
