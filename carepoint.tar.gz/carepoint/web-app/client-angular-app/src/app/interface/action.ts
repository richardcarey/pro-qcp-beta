export interface Action {
	name: string,
	activity_id: string
}
  