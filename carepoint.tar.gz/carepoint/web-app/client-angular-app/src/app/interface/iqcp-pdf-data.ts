export interface IqcpPdfData {
	url: string,
	pdfB64: string
}
  