import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountCentralComponent } from './account-central/account-central.component';
import { ToolComponent } from './tool/tool.component';
import { ProgramComponent } from './tool/program/program.component';
import { RiskComponent } from './tool/risk/risk.component';
import { QualityChecklistComponent } from './tool/quality-checklist/quality-checklist.component';
import { IqcpComponent } from './tool/iqcp/iqcp.component';
import { ReferenceComponent } from './tool/reference/reference.component';
import { HelpComponent } from './tool/help/help.component';
import { AccountEditComponent } from './account-central/account-edit/account-edit.component';
import { OverviewComponent } from './tool/overview/overview.component';
import { RiskAssessmentComponent } from  './tool/risk/risk-assessment/risk-assessment.component'
import { SuggestionReportComponent } from './tool/risk/risk-assessment/suggestion-report/suggestion-report.component';
import { FishboneGeneratorComponent } from './tool/fishbone-generator/fishbone-generator.component';
import { Role } from './models/role';
import { UnauthorizedComponent } from './tool/unauthorized/unauthorized.component';
import { AuthGuard } from './helpers/auth.guard';
import { UnauthenticatedComponent } from './tool/unauthenticated/unauthenticated.component';


const routes: Routes = [
  { path: 'account-central', 
    component: AccountCentralComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
  },
  {
    path: 'account-central/edit-account',
    component: AccountEditComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
  },
  {
    path: '',
    component: ToolComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] },
    children: [
      {path: '', redirectTo: 'overview', pathMatch: 'full'},
      {
        path: 'overview/:overviewData',
        component: OverviewComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'overview',
        component: OverviewComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'program/:programData',
        component: ProgramComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] }
      },
      {
        path: 'program',
        component: ProgramComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] }
      },
      {
        path: 'risk',
        component: RiskComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] }
      },
      {
        path: 'risk/:riskData',
        component: RiskComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] },
        children: [
          {
            path: 'risk-assessment/:riskData/:riskCategory',
            component: RiskAssessmentComponent,
            canActivate: [AuthGuard],
            data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] },
          },
        ]
      },
      {
        path: 'quality-checklist/:checklistData',
        component: QualityChecklistComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] }
      },
      {
        path: 'quality-checklist',
        component: QualityChecklistComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic] }
      },
      {
        path: 'iqcp/:iqcpData',
        component: IqcpComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'suggestion-report/:orderItem',
        component: SuggestionReportComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'reference/:referenceData',
        component: ReferenceComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'reference',
        component: ReferenceComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'help/:helpData',
        component: HelpComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      },
      {
        path: 'help',
        component: HelpComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin, Role.LabDirector, Role.Customer, Role.Basic, Role.RegulatoryAffairsManager] }
      }
    ]
  },
  {
    path: 'fishbone-generator/:riskAssessment',
    component: FishboneGeneratorComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.Admin] }
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent
  },
  {
    path: 'unauthenticated',
    component: UnauthenticatedComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule { }