import { element } from 'protractor';
import { RiskAssessment } from './../../interface/risk-assessment';
import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { DataService } from './../../services/data.service';
import { MatDialog } from '@angular/material/dialog';
import { InfoComponent } from 'src/app/dialogs/info/info.component';

@Component({
  selector: 'app-program',
  templateUrl: './program.component.html',
  styleUrls: ['./program.component.scss']
})


export class ProgramComponent implements OnInit {
  @Input() userDataChange;
  programData: RiskAssessment;
  programParam;
  directorName: string;
  directorTitle: string;
  ward: string;
  wards: []
  subscription;
  accreditingAgencies: string [] = []
  patient_test_per_month: number;
  wardDataSource = [];
  displayedColumns: string[] = ['ward', 'amount', 'action'];
  totalTest: number;
  isModuleActive = false;
  pageLoaded = false;
  programDevice: string;
  currentProgramData;
  isGeneric: boolean = false;
  
  accreditingAgencyOptions: any [] = [
    {value: "CAP"},
    {value: "TJC"},
    {value: "COLA"},
    {value: "CLIA"},
    {value: "Other"},
  ]
  userData: any;
  currentUserRole: string;
  canEditDirectorNameAndTitle = ["administrator", "customer", "lab_director"];
  constructor(
    private route: ActivatedRoute, 
    private _ApiService: ApiService, 
    private _DataService: DataService, 
    private Router: Router,
    private dialog: MatDialog,
    ) { }

  ngOnInit(): void {

    this.currentUserRole = this._DataService.currentUserRole;
    this._DataService.itemChange.next('Program Information');
    this._ApiService.getToken();
    this.route.paramMap.subscribe(params => {
      this.programParam = params.get('programData');
      this.checkIsModuleExpired(this.programParam);
      this.getRiskAssessment();
      // pass changed risk assessment data via data service so other components can subscribe
      this._DataService.changeProgramModule(this.programData);
    });
    this.subscription = this._DataService.currentRiskEvent.subscribe(submitData => {

      // Check if data submit is triggered
      if (submitData == true) {
        this.postProgramData()
      }
    });

  }
  ngOnDestroy() {
    if(typeof this.subscription !== "undefined"){
      this.subscription.unsubscribe();
    }
    if(typeof this.currentProgramData !== "undefined"){
      this.currentProgramData.unsubscribe();
    }
  }

  addWard() {
    if ((this.ward !== undefined && this.ward.trim() != "") && (this.patient_test_per_month != 0 && this.patient_test_per_month != undefined)) {
      this.wardDataSource.push({ward: this.ward, patient_test_per_month: this.patient_test_per_month, index: this.wardDataSource.length});
      this.wardDataSource = [...this.wardDataSource];
      this.setProgramModuleData();
      delete this.patient_test_per_month;
      delete this.ward;
    }
  }

  // Update risk assessment data
  setProgramModuleData() {
    var wards = this.wardDataSource;
    wards = wards.map((item) => {
      let itemClone = { ...item };
      delete itemClone.index;
      return itemClone;
    });

    this.programData.laboratory_director_name = this.directorName;
    this.programData.laboratory_director_title = this.directorTitle;
    this.programData.device = this.programDevice;
    this.programData.wards = wards;
    this.totalPatientTest();
  }

  addAccreditingAgency(value, e) {
    if ((e.checked)) {
      this.programData.accrediting_agency.push(value);
    }
    else {
      this.programData.accrediting_agency.splice(this.programData.accrediting_agency.indexOf(value), 1)
    }
  }

  // Remove items from ward table
  removeItem (index) {
    for (let i = 0; i < this.wardDataSource.length; i++) {
      if (this.wardDataSource[i].index == index) {
        this.wardDataSource.splice(this.wardDataSource.indexOf(this.wardDataSource[i]), 1);
      }
    }
    this.wardDataSource = [...this.wardDataSource];
    this.setProgramModuleData();
  }
  
  // Get risk assessment data via service
  getRiskAssessment() {
    this.currentProgramData = this._DataService.currentProgramModule.subscribe(programData => {
      // Check if there are any riskAssessmentData items
      if (programData != undefined && Object.keys(programData).length !== 0) {
        this.programData = programData
        this.prepareRiskAssessmentData()
        
        this.totalPatientTest();
      }
      else {
        this._ApiService.getRiskAssessment(this.programParam).subscribe((data) => {
          this.programData = data.pop();
          this.prepareRiskAssessmentData()
          
          this.totalPatientTest();
        })
      } 
    })
  }

  accreditingAgencyChecked(element) {  
    if (this.programData.accrediting_agency.includes(element.value)) {
      return true;
    }
    return false;
  }

  totalPatientTest() {
    let test_count = 0;
    for(let i = 0; i < this.programData.wards.length; i++) {
      test_count = parseInt(this.programData.wards[i].patient_test_per_month) + test_count;
    }
    this.totalTest = test_count;
  }

  postProgramData() {  
    if (this.programData != undefined) {
      
      // Check if Risk Assessment is missing order ID, assign param data
      if ((this.programData.order_id == undefined) || (this.programData.order_id == "")) {
        this.programData.order_id = this.programParam;
      }
      this._DataService.postProgramData(this.programData);
    }
  }

  jumpToMenuTrigger(category) {
    this._DataService.jumpToMenuTrigger(category, this.programParam);
  }

  emitAssessmentPostNext() {
    this.postProgramData();
    this.jumpToMenuTrigger('S')
  }

  resetNumValue(fieldName) {
    delete this[`${fieldName}`];
  }
  
  showWardsInfo() {
    this.dialog.open(InfoComponent, {
      width: '80%',
      data: {
        title: 'Location/Department Listing',
        paragraphOne: 'Enter the locations/departments covered by this IQCP. If one location or set of locations (e.g., LifeFlight or NICU) present a unique set of risks, you will ' +
        'want to complete a separate IQCP for that location.',
        paragraphTwo: 'Pro-QCP will help you determine the expected frequency of occurence of risks, based on the volume of testing. Enter the historical or estimated volume ' +
        'of testing at each location.'
      }
    });
  }

  checkIsModuleExpired(order_item_id){
    this._ApiService.checkIsModuleExpired(order_item_id).subscribe((data) => {
      this.pageLoaded = true;
      this.isModuleActive = data;
    })
  }
  prepareRiskAssessmentData() {
    this.directorName = this.programData.laboratory_director_name;
    this.directorTitle = this.programData.laboratory_director_title;
    this.programDevice = this.programData.device;
    this.isGeneric = (this.programData.is_generic !== undefined) && this.programData.is_generic.toLowerCase() == "y" ? true : false; 
    this.wardDataSource = this.programData.wards.map((item, index)=> {
      item.index = index;
      return item;
    })
  }
}
