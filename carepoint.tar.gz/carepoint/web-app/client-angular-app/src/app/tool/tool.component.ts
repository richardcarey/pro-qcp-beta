import { RiskAssessment } from 'src/app/interface/risk-assessment';
import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { StateService } from '../services/state.service';
import { DialogComponent } from './risk/dialog/dialog.component';
import { ApiService } from '../services/api.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DataService } from './../services/data.service';
@Component({
  selector: 'app-tool',
  templateUrl: './tool.component.html',
  styleUrls: ['./tool.component.scss']
})
export class ToolComponent implements OnInit {
  events: string[] = [];
  currentUserRole: string;
  canSaveProgress = false;
  opened = true;
  public menuItems = [];
  public orderData;
  public orderId;
  public selectedSideItem = 'Overview';
  public programData: RiskAssessment
  private _uid;
  riskPost: Subject<boolean> = new Subject<boolean>();
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(
    private breakpointObserver: BreakpointObserver, 
    public dialog: MatDialog, public state: StateService,
    private apiService: ApiService, 
    private activatedRoute: ActivatedRoute, 
    private _DataService: DataService,
    ) {
      this._DataService.currentItem.subscribe(res => {
        this.selectedSideItem = res;
      });
    }

  public ngOnInit() {
    this.apiService.getToken();
    this.currentUserRole = this._DataService.currentUserRole;
    this._uid = this._DataService.currentUserData.UID
    let canSaveProgressRoles = ["administrator", "lab_director", "customer","lab_tech"];
    this.canSaveProgress = canSaveProgressRoles.indexOf(this.currentUserRole) !== -1 
    this.activatedRoute.children[0].params.subscribe(res => {
      const keys = Object.keys(res);
      this.orderId = res[keys[0]];
      this.menuItems = [
        {title: 'Overview', path: '/overview/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech","regulatory_affairs_manager"] },
        {title: 'Program Information', path: '/program/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech"] },
        {title: 'Risk Assessment', path: '/risk/' + this.orderId + '/risk-assessment/' + this.orderId + '/S', canAccessRoles : ["administrator", "lab_director","customer","lab_tech"] },
        {title: 'Quality Checklist', path: '/quality-checklist/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech"]},
        {title: 'IQCP Print/Save', path: '/iqcp/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech","regulatory_affairs_manager"]},
        {title: 'Suggestion Report', path: '/suggestion-report/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech","regulatory_affairs_manager"]},
        {title: 'Help', path: '/help/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech","regulatory_affairs_manager"]},
        {title: 'Reference', path: '/reference/' + this.orderId, canAccessRoles : ["administrator", "lab_director","customer","lab_tech","regulatory_affairs_manager"]}
      ];
    });
    this.getRiskAssessment()
    this.getOrderData();
  }

  getOrderData() {
    let serviceEndpointResource = 'api/get_order_data';
    this.apiService.getSelectedOrder(this.orderId, serviceEndpointResource).subscribe(res => {
      this.orderData = res;
    });
  }

  emitAssessmentPost(event) {
    event.stopPropagation();
      // trigger global save for risk assessment data
      this._DataService.changeRiskEvent(true);
  }

    // Get risk assessment data via service
    getRiskAssessment() {
      this.apiService.getRiskAssessment(this.orderId).subscribe((data) => {
        this.programData = data.pop();
        // pass changed risk assessment data via data service so other components can subscribe
        this._DataService.changeProgramModule(this.programData);
      })
    }
}
