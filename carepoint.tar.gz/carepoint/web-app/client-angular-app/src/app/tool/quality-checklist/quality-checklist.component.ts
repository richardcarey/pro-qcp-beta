import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QualityChecklist } from 'src/app/interface/quality-checklist';
import { RiskAssessment } from 'src/app/interface/risk-assessment';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-quality-checklist',
  templateUrl: './quality-checklist.component.html',
  styleUrls: ['./quality-checklist.component.scss']
})
export class QualityChecklistComponent implements OnInit {
  isModuleActive = false;
  pageLoaded = false;
  public standards: QualityChecklist[] = [
    {
      title: 'Patient Test Managment',
      description: 'The first standard emphasizes having a system in place for monitoring and evaluating the procedures for Patient Test Management, including:',
      list: ['Patient preparation', 'Specimen collection', 'Labeling', 'Preservation and transportation', 'Test requisition completeness',
             'Relevance and necessity for testing', 'Use of appropriate criteria for specimen rejection', 'Test report completeness',
             'Relevance and accuracy', 'Timely reporting of results', 'Accuracy and reliability of test reporting systems'],
      checked: false
    },
    {
      title: 'Quality Control',
      description: 'The second standard is quality control. The lab is to have systems in place to evaluate the effectiveness of corrective actions in regard to the QC program, including:',
      list: ['Problems identified during the evaluation of calibration and QC', 'Problems identified during the evaluation of patient test results (to verify the reference range of a test method)',
             'Errors detected in results'],
      checked: false
    },
    {
      title: 'Proficiency Testing',
      description: 'The third standard is proficiency testing. The lab is to assess the effectiveness of corrective action taken to address any unacceptable, unsatisfactory, or unsuccessful PT results.The second standard is quality control. The lab is to have systems in place to evaluate the effectiveness of corrective actions in regard to the QC program, including:',
      checked: false
    },
    {
      title: 'Comparison of Test Results',
      description: 'The fourth standard is a comparison of test results. If a laboratory has more than one ' +
      'method of performing the same test, the lab must (twice a year) evaluate and define the ' +
      'relationship between the two methods (i.e., run the same specimen by each method and ' +
      'check for comparable results). If the lab performs testing on non-regulated analytes, the lab ' +
      'must have a method for verifying the accuracy of its test results. Proficiency testing or split ' +
      'sampling may be used.',
      checked: false
    },
    {
      title: 'Internal Quality Assurance',
      description: 'The fifth standard involves the relationship of patient information to patient test results. ' +
      'This is an internal quality assurance function. The lab must have a system in place to identify and ' +
      'evaluate patient test results when they appear inconsistent such criteria as the patient\'s age, ' +
      'sex, diagnosis, and the relationship with other test results.',
      checked: false
    },
    {
      title: 'Involves Personnel Assessment',
      description: 'The sixth standard involves personnel assessment. The laboratory must have a system in ' +
      'place to evaluate the effectiveness of its policies and procedures for assuring employee ' +
      'competence. If the lab has an outside consultant, the lab should have a method for ' +
      'evaluating his/her effectiveness, also.',
      checked: false
    },
    {
      title: 'Involves Communications',
      description: 'The seventh standard involves communications. The lab must have a mechanism for ' +
      'documenting problems arising as a result of a breakdown in communication. Corrective ' +
      'actions must be taken to both resolve the problem and minimize future communication breakdowns.',
      checked: false
    },
    {
      title: 'Addresses Complaint Investigations',
      description: 'The eighth standard addresses complaint investigations. The lab must have a system to ' +
      'assure that all complaints and problems are documented. Investigations must be made and corrective action taken.',
      checked: false
    },
    {
      title: 'Quality Assurance Review with Staff',
      description: 'The ninth standard is quality assurance review with staff. In addition to documenting and ' +
      'assessing problems identified in QA reviews, the lab personnel must discuss the issues and ' +
      'take corrective action to prevent recurrences.',
      checked: false
    },
    {
      title: 'Addresses QA Records',
      description: 'The tenth standard addresses QA records. Documentation of all QA activities must be made ' +
      'available to the Department of Health and Human Services.',
      checked: false
    }
  ];
  public qualityParam;
  public riskAssesments: RiskAssessment;
  public subscription;
  public isOpenedPage = false;
  constructor(private _ApiService: ApiService,
              private dataService: DataService,
              private route: ActivatedRoute) { 
    this.subscription = this.dataService.currentRiskEvent.subscribe(submitData => {
      if (this.riskAssesments && (!this.riskAssesments.quality_assessments || this.riskAssesments.quality_assessments === '' || 
      this.riskAssesments.quality_assessments === [])) {
        this.riskAssesments.quality_assessments = this.standards;
      }
      // Check if data submit is triggered
      if (submitData == true && this.isOpenedPage) {
        this.emitAssessmentPostNext();
      }
    });
  }

  ngOnInit(): void {
    this.dataService.itemChange.next('Quality Checklist');
    this._ApiService.getToken();
    this.route.paramMap.subscribe(params => {
      this.qualityParam = params.get('checklistData');
      this.checkIsModuleExpired(this.qualityParam);
      this.getRiskAssessment();
    });
  }

  answer() {
    this.riskAssesments.quality_assessments = this.standards;
    this.emitAssessmentPostNext();
  }

  getRiskAssessment() {
    this._ApiService.getRiskAssessment(this.qualityParam).subscribe((data) => {
      this.riskAssesments = data.pop();
      this.standards = this.riskAssesments.quality_assessments && this.riskAssesments.quality_assessments.length > 0 ?
      this.riskAssesments.quality_assessments : this.standards;
      this.isOpenedPage = true;
    });
  }

  postQualityData() {
    this.dataService.postQualityData(this.riskAssesments);
  }

  jumpToMenuTrigger(category) {
    this.dataService.jumpToPrint(category);
  }

  emitAssessmentPostNext() {
    this.postQualityData();
    this.jumpToMenuTrigger(this.qualityParam);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  checkIsModuleExpired(order_item_id){
    this._ApiService.checkIsModuleExpired(order_item_id).subscribe((data) => {
      this.pageLoaded = true;
      this.isModuleActive = data;
    })
  }

}
