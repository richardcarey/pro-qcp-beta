import { Component, OnInit } from '@angular/core';
import { Router, Event, ActivatedRoute } from '@angular/router';
import { NavigationStart, NavigationError, NavigationEnd } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';
import { keyValuesToMap } from '@angular/flex-layout/extended/typings/style/style-transforms';
import * as domtoimage from 'dom-to-image';

@Component({
  selector: 'app-fishbone-generator',
  templateUrl: './fishbone-generator.component.html',
  styleUrls: ['./fishbone-generator.component.scss']
})
export class FishboneGeneratorComponent implements OnInit {
  authorized: boolean = false;
  unauthorized: boolean = false;
  noAccessPermissions: boolean = false;
  hasAccessPermissions: boolean = false;
  riskData: any = [];
  risk_assessment_id: string;
  dataVersion: number;
  topArrow: string;
  specimen: any = [];
  testSystem: any = [];
  reagent: any = [];
  environment: any = [];
  testingPersonnel: any = [];
  colSize: any ;
  mainArrow: number = 16;
  pointerArrow : number = 13;
  assessment_name: string;
  constructor( 
    private authService: AuthService, 
    private router: Router,
    private _ApiService: ApiService,
    private route: ActivatedRoute) {
    this.checkIsUserAuthenticated();
   }

  ngOnInit() {
    this.topArrow = "600px";
    this._ApiService.getToken();
    this.route.paramMap.subscribe(params => {
      let riskData = params.get('riskAssessment');
      this.risk_assessment_id = params.get('riskAssessment');
      this.getRiskAssessment(riskData);
    });

  }

   checkIsUserAuthenticated(){
    this.authService.getUserData().subscribe((data) => {
      setTimeout(() => {
        if(typeof data !== "undefined"){
          this.authorized = true;
          if(data.roles[0] == "authenticated"){
            for(let [key, val] of Object.entries(data.roles)){
              if(val === "administrator"){
                this.hasAccessPermissions = true;
              }
            }

            if(!this.hasAccessPermissions){
              this.noAccessPermissions = true;
            }
          } else {
            this.unauthorized = true;
          }
        } 
      }, 1000);
    });
   }

   catchRouterEvent(roles){
      this.router.events.subscribe((event: Event) => {
        if (event instanceof NavigationStart) {
          this.routeAuthCheck(event.url, roles);
        }
      });
   }

   routeAuthCheck(route, roles){
   }

   getImage() {
    var node = document.getElementById('main-container');
    setTimeout(() => {
      return domtoimage.toJpeg(node, { quality: 0.95 })
      .then( (base64) => {
          var img = new Image();
          img.src = base64;
          this.storeFishboneDiagram(this.risk_assessment_id, base64);
          document.body.appendChild(img);
          this.downloadURI(base64, "fishbone.jpg");
          document.body.removeChild(img);
      });
    }, 300);

  }

  setText(id, text) {
    document.querySelector('#' + id).innerHTML = text;
  }

  downloadURI(base64, name) {
    var link = document.createElement("a");
    link.setAttribute("class", "fishbone-temp-image");
    link.download = name;
    link.href = base64;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
 
  getRiskAssessment(riskData) {
    
    const chunk = (arr, size) =>
      Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
      arr.slice(i * size, i * size + size)
    );
    this._ApiService.getRiskAssessmentTemplate(riskData).subscribe((data) => {
      
      if(data.length > 0){
         this.assessment_name = data[0].manufacturer__c + " " + data[0].test_system + " " + data[0].Cartridge;
         this.riskData = data[0].risks;
         this.specimen =  this.sortRisksBySize(this.riskData.filter(a => a.Cat == "S")) ;
         this.testSystem =  this.sortRisksBySize(this.riskData.filter(a => a.Cat == "T")) ;
         this.reagent =  this.sortRisksByActivity(this.riskData.filter(a => a.Cat == "R")) ;
         this.reagent = chunk(this.reagent, 3);
         this.environment =  this.sortRisksBySize(this.riskData.filter(a => a.Cat == "E"));
         this.testingPersonnel =  this.sortRisksBySize(this.riskData.filter(a => a.Cat == "P")) ;

        var allRisks = [
          this.testSystem, 
          // this.reagent, 
          this.environment, 
          this.specimen, 
          this.testingPersonnel
        ];
        
        let longestArrayIndex = allRisks.map(a=>a.length).indexOf(Math.max(...allRisks.map(a=>a.length)));
        let longestArray = allRisks[longestArrayIndex] ;
        let longestNestedArrayIndex = longestArray.map(a=>a.length).indexOf(Math.max(...longestArray.map(a=>a.length)));
        let longestNestedArray = longestArray[longestNestedArrayIndex];
        if(longestNestedArray.length >= 16){
          this.colSize = longestNestedArray.length + 5
        } else {
          this.colSize = 20;
        }

        this.mainArrow = this.colSize + 15;
        this.pointerArrow = this.colSize - 1;
      }
    })
  }

  getMaxRowCount(array){
    let arrayLength = 0;
    for(let [key, val] of Object.entries(array)){
      // if(Array.isArray(val)){
      //     let length = this.getMaxRowCount(val);
      //     arrayLength = length > arrayLength ? length : arrayLength;
      // } else {
        if(typeof val['value'] !== "undefined"){
          // arrayLength = arrayLength < val['value'].length ? val['value'].length : arrayLength;
          arrayLength = arrayLength + val['value'].length;
        }
      // }
    }
    return arrayLength;
  }

  sortRisksByActivity(risks){
    const sortedRisks = [];
    for(const [key, val] of Object.entries(risks)){
      const activityName = typeof val['Activity'] == "undefined" ||  val['Activity'] == "" ||  val['Activity'] == null ? "other" : val['Activity'];
      if(typeof sortedRisks[activityName] !== "undefined"){
        const arrayLength = sortedRisks[activityName].length
        sortedRisks[activityName][arrayLength] =  val;
      } else {
        sortedRisks[activityName] = [];
        sortedRisks[activityName][0] =  val;
      }

    }
    return  Object.keys(sortedRisks).map(key => ({type: key, value: sortedRisks[key]}));
  }

  sortRisksBySize(risks){
    const chunk = (arr, size) =>
      Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
      arr.slice(i * size, i * size + size)
    );
    let sortedRisks = chunk(risks, 20);
    let sortedRisksLength = sortedRisks.length;
    if(sortedRisksLength > 1){
      if(sortedRisks[sortedRisksLength - 1 ].length < 2){
        sortedRisks[sortedRisksLength -2][20] = sortedRisks[sortedRisksLength - 1 ][0];
        sortedRisks.splice(sortedRisksLength - 1, 1);
        // sortedRisks[sortedRisksLength - 1 ] = [];
      }
    }
    return  sortedRisks
  }

  storeFishboneDiagram(risk_assessment_id, base64){
    let postRequest = { 
      "risk_assessment_id": risk_assessment_id,
      "base64": base64
  };
    this._ApiService.storeFishboneDiagram(postRequest).subscribe((res: any) => {
    });
  }

}
