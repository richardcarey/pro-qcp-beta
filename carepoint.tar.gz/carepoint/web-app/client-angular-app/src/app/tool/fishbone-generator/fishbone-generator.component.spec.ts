import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FishboneGeneratorComponent } from './fishbone-generator.component';

describe('FishboneGeneratorComponent', () => {
  let component: FishboneGeneratorComponent;
  let fixture: ComponentFixture<FishboneGeneratorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FishboneGeneratorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FishboneGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
