import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IqcpComponent } from './iqcp.component';

describe('IqcpComponent', () => {
  let component: IqcpComponent;
  let fixture: ComponentFixture<IqcpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IqcpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IqcpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
