import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { LoadingPopupComponent } from 'src/app/dialogs/loading-popup/loading-popup.component';
import { PrintQcpDialogComponent } from 'src/app/dialogs/print-qcp-dialog/print-qcp-dialog.component';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';
import {RiskAssessment} from '../../interface/risk-assessment'
@Component({
  selector: 'app-iqcp',
  templateUrl: './iqcp.component.html',
  styleUrls: ['./iqcp.component.scss']
})
export class IqcpComponent implements OnInit {
  revisionData: any = [];
  iqcpRevisions : any;
  riskAssessmentData: any;
  iqcpRevisionsColumns: string[] = ['revision', 'summary', 'reason_for_change' , 'author', 'created',  'file'];
  public iqcpData;
  iqcpDataRevision: any = {};
  programModule: any;
  constructor(private dialog: MatDialog, private _ApiService: ApiService, private dataService: DataService, private route: ActivatedRoute) {}
  
  ngOnInit(): void {
    this.dataService.itemChange.next('IQCP Print/Save');
    this._ApiService.getToken();
    this.route.paramMap.subscribe(params => {
      this.iqcpData = params.get('iqcpData');
    });

    this.getRiskAssessment();
    
    this._ApiService.getIqcpRevision(this.iqcpData).subscribe((res: any) => {
      this.iqcpDataRevision.order_item_id = this.iqcpData
      this.iqcpRevisions = res;
    });
  }

  getRiskAssessment() {
    this._ApiService.getRiskAssessment(this.iqcpData).subscribe((data) => {
      this.riskAssessmentData = data.pop();
      if (this.riskAssessmentData !== undefined) {
        this.iqcpDataRevision.revision = this.riskAssessmentData.version
      }
    })
  }

  openPrintIqcpDialog() {
    const iqcpPrintsDialog = this.dialog.open(PrintQcpDialogComponent,{
      disableClose: true,
      height: '400px',
      width: '600px',
      data: this.iqcpDataRevision,
      panelClass: 'iqcp-revision-dialog'
    });

    iqcpPrintsDialog.afterClosed().subscribe(result => {
      setTimeout(() => {
        this._ApiService.getIqcpRevision(this.iqcpData).subscribe((res: any) => {
          this.iqcpRevisions = res;
        });
      }, 500);
    });
  }
}
