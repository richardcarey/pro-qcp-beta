import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-unauthenticated',
  templateUrl: './unauthenticated.component.html',
  styleUrls: ['./unauthenticated.component.scss']
})
export class UnauthenticatedComponent implements OnInit {

  constructor(
    private router: Router, 
    private authService: AuthService,
    private _DataService: DataService, 
    ) { 
    
  }

  ngOnInit(): void {
 
        this.authService.getUserData().subscribe((data) => {
          const currentUserRole = this._DataService.currentUserRole;;
          if (currentUserRole) {
              this.router.navigate(['/account-central'], { });
              }
        });
  }

}
