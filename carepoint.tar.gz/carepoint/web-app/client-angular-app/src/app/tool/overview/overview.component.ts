import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})
export class OverviewComponent implements OnInit {
  public overviewParam;
  constructor(private router: Router,
              private dataService: DataService,
              private _ApiService: ApiService,
              private route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      this.overviewParam = params.get('overviewData');
    });
  }

  ngOnInit(): void {
    this.dataService.itemChange.next('Overview');
  }

  next() {
    this.router.navigate(['/program/' + this.overviewParam]);
  }


}
