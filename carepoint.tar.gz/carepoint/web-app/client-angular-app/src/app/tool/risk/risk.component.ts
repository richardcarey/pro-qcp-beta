
import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { StateService } from 'src/app/services/state.service';
import { DialogComponent } from './dialog/dialog.component';
import { DataService } from '../../services/data.service'
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
@Component({
  selector: 'app-risk',
  templateUrl: './risk.component.html',
  styleUrls: ['./risk.component.scss']
})
export class RiskComponent implements OnInit {
  dialogTitle: string = 'Acceptability Matrix'
  programModule: any;
  subscription;
  riskCategory;
  isModuleActive = false;
  pageLoaded = false;
  currentRiskCategory: string;
 
  constructor(
    public dialog: MatDialog, 
    public state: StateService, 
    public route: ActivatedRoute,
    private apiService: ApiService,
    private _DataService: DataService
    ) {}
  links = [
    {value: 'S', title: 'Specimen'},
    {value:"T", title:"Test System"},
    {value:"R", title: "Reagent"},
    {value:"E", title:"Environment"},
    {value:"P", title:"Testing Personnel"}
  ];
  activeLink = this.links[0];
  public ngOnInit() {
    this._DataService.itemChange.next('Risk Assessment');
    this.subscription = this._DataService.categoryChange.subscribe(submitData => {
      if (submitData) {
        this.setActiveLink(submitData)
      }
    });

    this.route.paramMap.subscribe(params => {
      this.programModule = params.get('riskData');
      this.checkIsModuleExpired(this.programModule);
    });

    // Get child route category param
    this.route.firstChild.paramMap.subscribe(
      ( params) => {
        this.currentRiskCategory = params.get('riskCategory');
    });
    }
  ngOnDestroy() {
    if(typeof this.subscription !== "undefined"){
      this.subscription.unsubscribe();
    }
  }

  // Open Acceptability Matrix Template
  openAcceptabilityMatrixDialog() {
    if (this.isModuleActive){
      if (this.state.get('dialog_shown') === null || this.state.get('dialog_shown') === 'false'){
        this.apiService.getAcceptabilityMatrix(this.programModule).subscribe((data) => {
            const matrixData = data;
            if (!matrixData[0].version || matrixData[0].version.toString().length === 0) {
              this.openDialog();
            }
        });
      }
    }
  }

  setActiveLink(link) {
    this.activeLink = link;
  }
  public openDialog() {
    const dialogRef = this.dialog.open(DialogComponent,
      {
        height: '800px',
        width: '1050px',
        data: {
          dialogTitle: this.dialogTitle,
          programModule: this.programModule
        }
      });

    dialogRef.afterClosed().subscribe(result => {
      this.state.set('dialog_shown', result);
    });
  }
  checkIsModuleExpired(order_item_id){
    this.apiService.checkIsModuleExpired(order_item_id).subscribe((data) => {
      this.pageLoaded = true;
      this.isModuleActive = data;
      this.openAcceptabilityMatrixDialog();
    })
  }
}