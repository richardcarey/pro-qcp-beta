import { DataService } from 'src/app/services/data.service';
import { DOCUMENT } from '@angular/common';
import { Component, OnInit, Inject, Input} from '@angular/core';
import { FormControl, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { RiskAssessment } from 'src/app/interface/risk-assessment';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-add-risk',
  templateUrl: './add-risk.component.html',
  styleUrls: ['./add-risk.component.scss']
})
export class AddRiskComponent implements OnInit {
  @Input() riskAssessmentData: RiskAssessment;
  riskCategories: any [] = [
    {value: 'E', title: 'Environment'},
    {value: 'R', title: 'Reagent'},
    {value: 'S', title: 'Specimen'},
    {value: 'P', title: 'Personnel'},
    {value: 'T', title: 'System'},
  ];
  checked;
  addNewRiskForm: FormGroup;
  formFieldsInvalid: boolean;
  constructor(
    public dialog: MatDialog,
    @Inject(DOCUMENT) private _document: Document,
    private _DataService: DataService,
    private formBuilder: FormBuilder,
    private notifyService: NotificationService ) {
      this.addNewRiskForm = this.createFormGroup();
    }
  createFormGroup(): FormGroup {
    return new FormGroup({
        Cat: new FormControl(),
        RISK_Statement: new FormControl(),
        risk_citation: new FormControl(),
        poct_policy: new FormControl(),
        version: new FormControl(),
        title: new FormControl(),
        text: new FormControl(),
      });
  }
  ngOnInit(): void {

  }

  onSubmit(submitedValue){
    if (this.checkForInvalidFields()){
      const newIndex =
      (parseInt(this.riskAssessmentData.risks[this.riskAssessmentData.risks.length - 1].Index, 0) + 10).toString();
      const formatRiskValue = {
        Cat: submitedValue.Cat,
        Index: newIndex,
        RISK_Statement: submitedValue.RISK_Statement,
        citation: submitedValue.poct_policy + '<br>'
        + submitedValue.version + '<br>'
        + submitedValue.title + '<br>'
        + submitedValue.text + '<br>'
      };
      this.riskAssessmentData.risks.push(formatRiskValue);
      this.showToaster('New risk is added.', 'Risk Assessment', 'success');
      
      // save progress and trigger update on Risk list
      this._DataService.changeRiskEvent(true);
      setTimeout(() => {
        this.refreshPage();
      }, 5000);

      this.addNewRiskForm.reset();
      this.formFieldsInvalid = false;
    } else {
      this.showToaster('Please fill all required * fields', 'Risk Assessment', 'error');
      this.formFieldsInvalid = true;
    }
  }

  formValidation(fieldName: string) {
    return this.addNewRiskForm.controls[fieldName].value == '' ;
  }

  checkForInvalidFields() {
    const controls = this.addNewRiskForm.controls;
    for (const name in controls) {
      if(name != "risk_citation"){
        if( controls[name].value == "" || controls[name].value == null || typeof controls[name].value == "undefined"){
          return false;
        }
      }
    }
    return true;
  }

  showToaster(message, title, type) {
    if (type === 'success') {
    this.notifyService.showSuccess(message, title);
    } else {
    this.notifyService.showError(message, title);
    }
  }
  refreshPage() {
    this._document.defaultView.location.reload();
  }
}
