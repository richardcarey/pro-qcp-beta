import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskAcceptabilityMatrixComponent } from './risk-acceptability-matrix.component';

describe('RiskAcceptabilityMatrixComponent', () => {
  let component: RiskAcceptabilityMatrixComponent;
  let fixture: ComponentFixture<RiskAcceptabilityMatrixComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskAcceptabilityMatrixComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskAcceptabilityMatrixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
