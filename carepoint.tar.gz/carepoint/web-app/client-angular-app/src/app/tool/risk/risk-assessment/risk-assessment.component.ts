import { RiskAssessment } from '../../../interface/risk-assessment';
import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from './../../../services/data.service';
import { ApiService } from '../../../services/api.service';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-risk-assessment',
  templateUrl: './risk-assessment.component.html',
  styleUrls: ['./risk-assessment.component.scss']
})
export class RiskAssessmentComponent implements OnInit {
  programModule: any;
  @Input() riskAssessmentData: RiskAssessment;
  riskCategory;
  riskTitle;
  eventsSubject: Subject<void> = new Subject<void>();
  commonButtonName = 'Next';
  selectedTab = 0;
  nextCategory;
  links = [
    {value: 'S', title: 'Specimen'},
    {value:"T", title:"Test System"},
    {value:"R", title: "Reagent"},
    {value:"E", title:"Environment"},
    {value:"P", title:"Testing Personnel"}
  ];
  
  constructor(
    public route: ActivatedRoute,    
    private _ApiService: ApiService, 
    private _DataService: DataService,
    private Router: Router
    ) { }

  ngOnInit(): void { 
    this.route.paramMap.subscribe(params => {
      this.programModule = params.get('riskData');
    });

    this.route.paramMap.subscribe(params => {
      this.riskCategory = params.get('riskCategory');
      this.getRiskTitle();
    });

    this._DataService.currentQcpSaved.subscribe(data => {
      if (data == true && this.nextCategory !== undefined) {
        this.navigateToNextCategory();
      }
   });

    this._DataService.currentProgramModule.subscribe(programData => {
      // Check if there are any riskAssessmentData items
      if (Object.keys(programData).length !== 0) {
        this.riskAssessmentData = programData
      }
      else {
        this.getRiskAssessment()
      }
      
    })
    this.getRiskTitle();
   }

  
  getRiskAssessment() {
    this._ApiService.getRiskAssessment(this.programModule).subscribe((data) => {
      this.riskAssessmentData = data.pop();
    })
  }

  jumpToMenuTrigger(category) {
    this.Router.navigate(['/risk/' + this.programModule + '/risk-assessment/' + this.programModule + '/' + category]);
  }

  getRiskTitle() {
    let link = this.links.find((link) => {
      if (link.value == this.riskCategory) {
        this.riskTitle = link.title;
      }
    });
  }

  emitAssessmentPostNext() {
    
    if (this.selectedTab !== 3) {
      this._DataService.changeRiskEvent(true);

      for (let i = 0; i < this.links.length; i++) {
        if (this.links[i].value == this.riskCategory) {
          let nextIndex = this.riskCategory === 'P' ? i : i + 1;
          if (this.links[nextIndex] !== undefined) {
            this.nextCategory = this.links[nextIndex]
          }
          else {
            this.nextCategory = this.links[0]
          }
        }
      }
    } else {
      this.selectedTab = 0;
      this.commonButtonName = 'Next';
      this.eventsSubject.next();
    }
  }

  onTabChanged(selectedTab) {
    this.selectedTab = selectedTab.index;
    this.commonButtonName = 'Next';
    if (selectedTab.tab.textLabel === 'Show Progress') {
    this.getRiskAssessment();
    } else if (selectedTab.tab.textLabel === 'Acceptability Matrix') {
      this.commonButtonName = 'Done';
    }
  }

  navigateToNextCategory() {
    if (this.riskCategory !== 'P' ) {
      this.jumpToMenuTrigger(this.nextCategory.value);
      this._DataService.changeCategory(this.nextCategory.value);
    } else {
      this._DataService.jumpToQualityChecklist(this.programModule);
    }
    delete this.nextCategory;
  }
}
