import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QcpDialogComponent } from './qcp-dialog.component';

describe('QcpDialogComponent', () => {
  let component: QcpDialogComponent;
  let fixture: ComponentFixture<QcpDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QcpDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QcpDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
