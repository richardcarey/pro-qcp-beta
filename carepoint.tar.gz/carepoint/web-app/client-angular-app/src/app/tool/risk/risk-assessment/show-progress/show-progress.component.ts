import { Component, Input, OnInit } from '@angular/core';
import { RiskAssessment } from 'src/app/interface/risk-assessment';

@Component({
  selector: 'app-show-progress',
  templateUrl: './show-progress.component.html',
  styleUrls: ['./show-progress.component.scss']
})
export class ShowProgressComponent implements OnInit {

  @Input() riskAssessmentData: RiskAssessment;
  riskCategories: any [] = [
    {value: 'S', title: 'Specimen'},
    {value: 'T', title: 'System'},
    {value: 'R', title: 'Reagent'},
    {value: 'E', title: 'Environment'},
    {value: 'P', title: 'Personnel'}
  ];
  public progressData = {
    Environment: {
      risks: [],
      accepted: 0
    },
    Reagent: {
      risks: [],
      accepted: 0
    },
    Specimen: {
      risks: [],
      accepted: 0
    },
    Personnel: {
      risks: [],
      accepted: 0
    },
    System: {
      risks: [],
      accepted: 0
    }
  };
  public isReadyProgress = false;
  public progressValue = 0;
  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges() {
    if (this.riskAssessmentData) {
      this.clearRiskProgress();
      this.parsedProgressData();
    }
  }

  parsedProgressData() {
    this.riskAssessmentData.risks.forEach(risk => {
      switch (risk.Cat) {
        case 'E':
          this.progressData.Environment.risks.push(risk);
          this.progressData.Environment.accepted += risk.acceptance ? 1 : 0;
          break;
        case 'R':
          this.progressData.Reagent.risks.push(risk);
          this.progressData.Reagent.accepted += risk.acceptance ? 1 : 0;
          break;
        case 'S':
          this.progressData.Specimen.risks.push(risk);
          this.progressData.Specimen.accepted += risk.acceptance ? 1 : 0;
          break;
        case 'P':
          this.progressData.Personnel.risks.push(risk);
          this.progressData.Personnel.accepted += risk.acceptance ? 1 : 0;
          break;
        case 'T':
          this.progressData.System.risks.push(risk);
          this.progressData.System.accepted += risk.acceptance ? 1 : 0;
          break;
      }
    });
    this.calculateProgressValue();
  }

  calculateProgressValue() {
    const progressDataKeys = Object.keys(this.progressData);
    let allAcceptedRisks = 0;
    progressDataKeys.forEach(key => {
      allAcceptedRisks += this.progressData[key].accepted;
    });
    this.progressValue = Math.round((allAcceptedRisks / this.riskAssessmentData.risks.length) * 100);
    this.isReadyProgress = true;
  }

  clearRiskProgress() {
    this.progressData = {
      Environment: {
        risks: [],
        accepted: 0
      },
      Reagent: {
        risks: [],
        accepted: 0
      },
      Specimen: {
        risks: [],
        accepted: 0
      },
      Personnel: {
        risks: [],
        accepted: 0
      },
      System: {
        risks: [],
        accepted: 0
      }
    };
  }

}
