import { element } from 'protractor';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { QcpDialogComponent } from './qcp-dialog/qcp-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { LoadingPopupComponent } from '../../../../dialogs/loading-popup/loading-popup.component';
import { animate, state, style, transition, trigger } from '@angular/animations';

import { NotificationService } from '../../../../services/notification.service'
import { RiskAssessment } from '../../../../interface/risk-assessment'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from './../../../../services/data.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-qcp-form',
  templateUrl: './qcp-form.component.html',
  styleUrls: ['./qcp-form.component.scss'],
  animations: [
    trigger('expandableRow', [
      state('collapsed, void', style({
        height: '0px',
        visibility: 'hidden'
      })),
      state('expanded', style({
        'min-height': '48px',
        height: '*',
        visibility: 'visible'
      })),
      transition(
        'expanded <=> collapsed, void <=> *',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ),
    ]),
  ],
})

export class QcpFormComponent implements OnInit {
  @Input() programModule: any;
  checked;
  expandedElement = false;
  riskForm: FormGroup;
  severityOptions = [];
  probabilityOptions = [];
  recommendedProbability: string [];
  submitQCPDataArray = [];
  qcptPost: Subject<any[]> = new Subject<any []>();
  displayedColumns: string[] = ['risk', 'display', 'description', 'citation', 'severity', 'probability', 'like'];
  dataSource: any[];
  riskAssessmentFiltered: any[] = [];
  riskExposure: string;
  riskIds: any [];
  postQCPData: any [];
  riskIdsFilter: any [];
  qcpIds = [];
  riskQCPList: any [];
  subscription;
  qcpFiltered: any [];
  RiskAssessmentActive: boolean;
  isRiskEmpty: boolean = true;
  isQcpFilterEmpty: boolean = true;
  accreditingAgency: any[];
  currentProgramModule;
  riskSubscription;
  severityText:string = 'Assess the severity of harm caused by this risk and its frequency of occurrence (actual or estimated)';
  probabilityText:string = `Based upon your tolerance for risk (see Acceptability Matrix), your test volume, and the frequency of occurrence, Pro-QCP will suggest a probability of harm.  It is up to you to review the risk mitigation actions below, identify those that are current practice and those that you want to consider for the future, and to add any other QCP’s that your lab employs.   Once you go through this process for each risk, perform a final assessment that any residual risk that remains, in light of the QCP, is acceptable. 
  <br>
  <br>
  If your Risk Exposure is ‘acceptable’ from the start, perhaps due to low severity of harm or infrequent occurrence, your job is done and you can move onto the next risk.  
  <br>
  <br>
  If your Risk Exposure is ‘unacceptable’ you should identify mitigation actions (QCP’s) that will lower the chance of the risk occurring.  Once you have determined that you have mitigated the risk sufficiently, you can update the probability at the top, or check off “Residual Risk Acceptable” at the bottom and the Risk Acceptability will be updated automatically.`;
  @Input() riskAssessmentData: RiskAssessment;
  @Input() riskCategory;
  field_names = [
		'risk_present',
		'RISK_Statement',
		'severity',
    'typical_number_of_errors',
    'typical_number_of_errors_sec',
		'probability',
		'recommended_probability',
		'severity_options',
    'probability_options',
    'Cat',
    'Add_to_Risk_Table',
    'Activity',
    'Common_Risk',
    'Specific_Risk',
    'frequency',
    'acceptance',
    'created',
    'qcp',
    'row_id',
    'Index',
    'qcp_in_effect',
    'detectabilty',
    'detectabilty_improved',
    'risk_addressed',
    'acceptance_default'
  ];

  detectabiltyOptions = [
    'Not detectable',
    'Remote chance of detection',
    'Low chance of detection',
    'Moderately high chance of detection',
    'Always detectable'
  ]
  dataCheckbox = [
    {title: 'Written Policy', value: false},
    {title: 'Direct observation (patient testing)', value: true},
    {title: 'Quiz', value: false},
    {title: 'Proficiency Testing', value: false},
    {title: 'Training', value: false},
    {title: 'Direct observation(Maintanence)', value: true},
    {title: 'Problem solving', value: false},
    {title: 'Monitoring results', value: false},
  ];
  numberErrorOptions = [
    "Per Week",
    "Per Month",
    "Per Year",
    "Per Every 3 Years",
    "Per System Lifespan"
  ];
  public numPatients = 0;
  public valueProbability = '';
  public numErrors = 0;
  public percentageOfErrors;
  public period = 'Per Year';
  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder, 
    private _ApiService: ApiService, 
    private _NotificationService: NotificationService,
    private _DataService: DataService,
    ) { }

  ngOnInit(): void {
    this.buildForm();
    this.subscription = this._DataService.currentRiskEvent.subscribe(submitData => {

      // Check if data submit is triggered
      if (submitData == true) {
        this.onSubmit(submitData)
      }
    });

    this.riskSubscription = this._DataService.currentQcpChange.subscribe(currentRisk => {
      this.updateRiskCitation(currentRisk);
    });

    this.accreditingAgency = this.riskAssessmentData.accrediting_agency[0];
  }

   ngOnDestroy() {
    if (this.subscription != undefined) {
    this.subscription.unsubscribe();
    }
    if (this.currentProgramModule != undefined) {
    this.currentProgramModule.unsubscribe();
    }
    if (this.riskSubscription != undefined) {
      this.riskSubscription.unsubscribe();
      }
  }
  
  // Create a Risk Assessment form
  public buildForm() {
    let riskIds = [];
    let riskIdsFilter = []
    this.riskAssessmentFiltered = [];
		this.riskForm = this.fb.group({});
    this.countNumPatients(this.riskAssessmentData);
    for (let i= 0; i < this.riskAssessmentData.risks.length; i++) {
      riskIds.push(this.riskAssessmentData.risks[i].Index);
      if (this.riskAssessmentData.risks[i].Cat == this.riskCategory) {
        riskIdsFilter.push(this.riskAssessmentData.risks[i].Index);
        for (let a = 0; a < this.field_names.length; a++) {
          let disabled_control = (this.riskAssessmentData.risks[i].risk_present != true && this.field_names[a] !== 'risk_present')
          this.riskForm.addControl(this.field_names[a] + i,
            this.fb.control({value: this.riskAssessmentData.risks[i][`${this.field_names[a]}`], 
            disabled: disabled_control}, Validators.required));
          this.riskAssessmentData.risks[i].index_row = i;
          if (this.riskAssessmentData.risks[i].risk_addressed == undefined) {
            this.riskAssessmentData.risks[i].risk_addressed = [];
          }
          if (this.riskAssessmentData.risks[i].citation == undefined) {
            this.riskAssessmentData.risks[i].citation = '';
          }
          if (this.riskAssessmentData.risks[i].acceptance == undefined) {
            this.riskAssessmentData.risks[i].expanded = false;
          } else {
          if (!this.riskAssessmentData.risks[i].acceptance) {
            this.riskAssessmentData.risks[i].expanded = true;
          } else {
            this.riskAssessmentData.risks[i].expanded = false;
          }
        }
        }
        this.probabilityOptions[i] = [
          "Frequent",
          "Probable",
					"Occasional",
					"Remote",
					"Improbable"
				],
        this.severityOptions[i] = [
					"Negligible",
					"Minor",
					"Serious",
					"Critical",
					"Catastrophic"
				],
        this.riskAssessmentFiltered.push(this.riskAssessmentData.risks[i]) 
      }
    }
    for (let i= 0; i < this.riskAssessmentFiltered.length; i++) { 
      this.riskAssessmentFiltered[i].row_number = i;
      this.riskAssessmentFiltered[i].numError = 0;
      this.riskAssessmentFiltered[i].isRecognized = false;
    }
    this.riskIds = riskIds;
    this.riskIdsFilter = riskIdsFilter;
    this.getQCP();

    // Check if there are any risk items for given category
    if (Object.keys(this.riskForm.value).length !== 0) {
      this.isRiskEmpty = false;
    }

    this.dataSource = this.riskAssessmentFiltered;
  }
  
  public openDialog() {
    const dialogRef = this.dialog.open(QcpDialogComponent);

    dialogRef.afterClosed().subscribe(result => {  });
  }

  // Format and POST Risk assessment changes to service
  onSubmit(e = false) {
    if (e) {
      if (this.riskAssessmentData.order_id == "") {
        this.riskAssessmentData.order_id = this.programModule;
      }
      for (let i = 0; i < this.riskAssessmentData.risks.length; i++) {
        for (let a = 0; a < this.field_names.length; a++) {
          let category_field_name = 'Cat' + i;
          if (this.riskAssessmentData.risks[i].Cat == this.riskForm.value[`${category_field_name}`]) {
            this.riskAssessmentData.risks[i][`${this.field_names[a]}`] = this.riskForm.value[`${this.field_names[a] + i}`]
          }	
        }
      }
      this.postRiskAssessment();
    }
  }

	postRiskAssessment() {
    this.riskAssessmentData.active = true;
		this._ApiService.createRiskAssessment(this.riskAssessmentData).subscribe((data) => {
    this.emitAssessmentPost();
    })
    this.submitQCPDataArray = [];
  }

  getQCP() {
    this.checkRiskAsessmentActive();
    let qcpObject = {risk_ids: this.riskIds, order_id: this.programModule, active: this.RiskAssessmentActive, assessment_id: this.riskAssessmentData.assessment_id}
    this._ApiService.getQCP(qcpObject).subscribe((data) => {
      this.riskQCPList = data;
      this.formatQcpList();
      this.isQcpFilterEmpty = false;
    })
  }

  // Format QCP results and pass them to qcp form
  formatQcpList() {
    let qcpFiltered = [];
    let flatQCP = [];
    let qcpIds = [];
    let result = [];
    for (const [i, risId] of this.riskIds.entries()) {
      if (this.riskQCPList[i] !== undefined && this.riskQCPList[i] !== null) {
        result = this.riskQCPList[i].filter(obj => {
          flatQCP.push(obj);
          qcpIds.push(obj.QCP_ID);
          if (obj !== undefined && obj !== null) {
            return obj.risk_id == risId;
          }   
        })
      }
      qcpFiltered.push({risk_id: risId, qcps: result})
    }
    this.qcpIds = qcpIds.sort((a, b) => a - b)
    this.postQCPData = flatQCP;
    this.getQcpByCategory(qcpFiltered);
  }

  // Filter QCP`s by category
  getQcpByCategory(qcpFiltered) {
    let qcpsFilteredCategory = [];

    for (let i = 0; i < qcpFiltered.length; i++) {
      if (this.riskIdsFilter.includes(qcpFiltered[i].risk_id)) {
        qcpsFilteredCategory.push(qcpFiltered[i]);
      }
    }

    this.qcpFiltered = qcpsFilteredCategory;
    
    // Check if there are any qcp items
    if (Object.keys(this.qcpFiltered).length === 0) {
      this.isQcpFilterEmpty = true;
    }
  }

  riskAddressedChecked(element, index) {  
    if (this.riskAssessmentData.risks[index].risk_addressed !== undefined) {
      if (this.riskAssessmentData.risks[index].risk_addressed.includes(element.title)) {
        return true;
      }
    }
    return false;
  }

  addRiskAddressed(value, e, index) {
    if ((e.checked)) {
      this.riskAssessmentData.risks[index].risk_addressed.push(value);
    }
    else {
      this.riskAssessmentData.risks[index].risk_addressed.splice(this.riskAssessmentData.risks[index].risk_addressed.indexOf(value), 1);
    }
  }
  
  emitAssessmentPost() {
    this.qcptPost.next(this.riskIds);
  }

  submitQcpData(e) {
    this.submitQCPDataArray.push(e);
    if (this.submitQCPDataArray.length == this.riskIdsFilter.length) {
      this.openProgressDialog('Saving Progress, Please wait...')
      this.prepareQcpdata();
    }
  }

  // Prepare the array of QCP items for POST via service
  prepareQcpdata() {
    let itemAdd = [];
    for (let i= 0; i < this.submitQCPDataArray.length; i++) {
      for (let a = 0; a < this.submitQCPDataArray[i].qcps.length; a++) {
        this.postQCPData.forEach((item, index) => {
          item.order_id = this.programModule;
          item.version = this.riskAssessmentData.version;
          this.submitQCPDataArray[i].qcps[a].order_id = item.order_id;
          if ((item.QCP_ID == this.submitQCPDataArray[i].qcps[a].QCP_ID) && (item.risk_id == this.submitQCPDataArray[i].qcps[a].risk_id)) {
            this.postQCPData[index] = this.submitQCPDataArray[i].qcps[a];
          }
          else if ((this.submitQCPDataArray[i].qcps[a].isNew == true)
           && this.submitQCPDataArray[i].qcps[a].Action != null
           && this.submitQCPDataArray[i].qcps[a].Action != "") {
            delete this.submitQCPDataArray[i].qcps[a].isNew;
            itemAdd.push(this.submitQCPDataArray[i].qcps[a]);
          }
        });
      }
    }
    itemAdd = [...new Set(itemAdd)];
    this.postQCPData =this.postQCPData.concat(itemAdd);
    this.postQCP();
  }


  // Post QCP data via service
  postQCP() {
    this._ApiService.createQCP(this.postQCPData).subscribe((data) => {
      this.dialog.closeAll();
      this._NotificationService.showSuccess('Successfully updated Risk Assessment', 'Risk Assessment');
      this._DataService.changeRiskEvent(false);
      this._DataService.changeQcpSavedEvent(true);
     })
  }
  checkAcceptabilitymatrix(index) {
    let severity = this.riskForm.controls['severity' + index].value;
    let probability = this.riskForm.controls['probability' + index].value;
    if (severity && probability) {
      this.riskAssessmentData.risks[index].isRecognized = true;
    }
    let item = this._DataService.calculateRiskAcceptability(severity, probability);
    if (item[0] !== undefined) {
      let acceptance = parseInt(item[0].acceptance);
      this.riskAssessmentData.risks[index].acceptance = acceptance;
      this.riskAssessmentData.risks[index].acceptance_default = acceptance;
      let risk = this.dataSource.filter(item => {
        if (item.Index == this.riskAssessmentData.risks[index].Index) {
          return item;
        }
      })

      if (risk !== undefined) {
        risk[0].acceptance = acceptance;
        risk[0].acceptance_default = acceptance;
      }

      this.dataSource = [... this.dataSource];
      this.riskForm.controls['acceptance' + index].setValue(acceptance);
      this.riskForm.controls['acceptance_default' + index].setValue(acceptance);
    }
  }

  countNumPatients(risk) {
    risk.wards.forEach(ward => {
      this.numPatients += ward.patient_test_per_month;
    });
  }

  changeNumErrors(period, element) {
    if (period) {
      this.period = period.value;
    }
    const patientsPerYear = this.numPatients * 12;
    switch (this.period) {
      case 'Per Week':
        this.percentageOfErrors = (element.typical_number_of_errors_sec / (patientsPerYear / 52)) * 100;
        break;
      case 'Per Month':
        this.percentageOfErrors = (element.typical_number_of_errors_sec / (patientsPerYear / 12)) * 100;
        break;
      case 'Per Year':
        this.percentageOfErrors = (element.typical_number_of_errors_sec / patientsPerYear) * 100;
        break;
      case 'Per Every 3 Years':
        this.percentageOfErrors = (element.typical_number_of_errors_sec / (patientsPerYear * 3)) * 100;
        break;
      case 'Per System Lifespan':
        this.percentageOfErrors = (element.typical_number_of_errors_sec / (patientsPerYear * 6)) * 100;
        break;
    }
    this.getProbability(element);
  }

  getProbability(element) {
      if (this.percentageOfErrors >= 0 && this.percentageOfErrors <= 10) {
        element.valueProbability = 'Very Low';
      } else if (this.percentageOfErrors >= 11 && this.percentageOfErrors <= 30) {
        element.valueProbability = 'Low';
      } else if (this.percentageOfErrors >= 31 && this.percentageOfErrors <= 50) {
        element.valueProbability = 'Medium';
      } else if (this.percentageOfErrors >= 51 && this.percentageOfErrors <= 80) {
        element.valueProbability = 'High';
      } else {
        element.valueProbability = 'Very High';
      }
  }
  

  openToolTipDialog(toolTipText, title, width) {
    const dialogRef = this._DataService.openToolTipDialog(toolTipText, title, width);
  }

  updateRiskCitation(risk) {
    for (let i = 0; i < this.riskAssessmentData.risks.length; i++) {
      if (this.riskAssessmentData.risks[i].Index == risk.Index) {
        this.riskAssessmentData.risks[i].citation = encodeURI(risk.citation);
      }
    }
  }

  openCitationDialog(risk, title, width) {
    const dialogRef = this._DataService.openCitationpDialog(risk, title, width);
  }

  openProgressDialog(message) {
    const dialogRef = this.dialog.open(LoadingPopupComponent,
    {
      data: {
        message: message
      },
      disableClose: true
    });
  }
  
  changeRiskPresent(element) {
    if (element.risk_present == true) {
      this.field_names.forEach(ctrl => {
        if (ctrl !== 'risk_present') {
          this.riskForm.controls[ctrl + element.index_row].disable();
        }
      });
      element.risk_present = false;
    }
    else {
      this.field_names.forEach(ctrl => {
        this.riskForm.controls[ctrl + element.index_row].enable();
      });
      element.risk_present = true;
    }   
  }

  checkRiskAsessmentActive() {
    if ((this.riskAssessmentData.active != undefined && this.riskAssessmentData.active == true)) {
      this.RiskAssessmentActive = true;
    }
    else {
      this.RiskAssessmentActive = false;
    }
  }
}