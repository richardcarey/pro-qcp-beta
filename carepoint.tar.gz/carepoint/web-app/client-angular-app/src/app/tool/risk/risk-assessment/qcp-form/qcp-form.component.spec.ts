import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QcpFormComponent } from './qcp-form.component';

describe('QcpFormComponent', () => {
  let component: QcpFormComponent;
  let fixture: ComponentFixture<QcpFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QcpFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QcpFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
