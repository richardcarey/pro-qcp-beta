import { Component, Input, OnInit } from '@angular/core';
import { keyValuesToMap } from '@angular/flex-layout/extended/typings/style/style-transforms';
import { ActivatedRoute } from '@angular/router';
import * as domtoimage from 'dom-to-image';
import { RiskAssessment } from 'src/app/interface/risk-assessment';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';
@Component({
  selector: 'app-risk-fishbone',
  templateUrl: './risk-fishbone.component.html',
  styleUrls: ['./risk-fishbone.component.scss']
})
export class RiskFishboneComponent implements OnInit {
  @Input() riskAssessmentData: RiskAssessment;
  riskData: any = [];
  orderItemID: string;
  dataVersion: number;
  topArrow: string;
  specimen: any = [];
  testSystem: any = [];
  reagent: any = [];
  environment: any = [];
  testingPersonnel: any = [];
  colSize: any ;
  mainArrow: number = 16;
  pointerArrow : number = 13;
  assessment_name: string;
  base64Fishbone: any;

  constructor(
    private _ApiService: ApiService, 
    private route: ActivatedRoute,
    private _DataService: DataService
    ) { }

  ngOnInit(): void {
    this.getRiskAssesmentTemplate();
  }

  getRiskAssesmentTemplate(){
    if (Object.keys(this.riskAssessmentData).length !== 0) {
      this.getFishboneImage(this.riskAssessmentData.assessment_id);
    }
  }

  getFishboneImage(risk_assesment) {
    
    this._ApiService.getFishboneByRiskAssesment(risk_assesment).subscribe((data) => {
      if(data.length > 0){
        this.base64Fishbone = "data:image/jpeg;base64," + data[0].field_fishbone;
      }
    });

  }

  getImage() {
    if(this.base64Fishbone){
      this.downloadURI(this.base64Fishbone, "fishbone.jpg");
    }
    

  }
  downloadURI(base64, name) {
    var link = document.createElement("a");
    link.setAttribute("class", "fishbone-temp-image");
    link.download = name;
    link.href = base64;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
