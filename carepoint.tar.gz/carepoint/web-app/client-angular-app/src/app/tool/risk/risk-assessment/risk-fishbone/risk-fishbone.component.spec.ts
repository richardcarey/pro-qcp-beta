import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskFishboneComponent } from './risk-fishbone.component';

describe('RiskFishboneComponent', () => {
  let component: RiskFishboneComponent;
  let fixture: ComponentFixture<RiskFishboneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskFishboneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskFishboneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
