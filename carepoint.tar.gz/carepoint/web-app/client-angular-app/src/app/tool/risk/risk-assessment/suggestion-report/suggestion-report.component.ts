import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { PrintSuggestionReportComponent } from 'src/app/dialogs/print-suggestion-report/print-suggestion-report.component';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-suggestion-report',
  templateUrl: './suggestion-report.component.html',
  styleUrls: ['./suggestion-report.component.scss']
})
export class SuggestionReportComponent implements OnInit {
  revisionData: any = [];
  suggestionReportRevisions : any;
  riskAssessmentData: any;
  suggestionReportRevisionsColumns: string[] = ['revision', 'summary', 'reason_for_change' , 'author', 'created',  'file'];
  public suggestionReportData;
  suggestionReportRevision: any = {};
  programModule: any;
  constructor(private dialog: MatDialog, private _ApiService: ApiService, private dataService: DataService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.dataService.itemChange.next('Suggestion Report');
    this._ApiService.getToken();
    this.route.paramMap.subscribe(params => {
      this.suggestionReportData = params.get('orderItem');
    });

    this.getRiskAssessment();
    
    this._ApiService.getSuggestionReportRevision(this.suggestionReportData).subscribe((res: any) => {
      this.suggestionReportRevision.order_item_id = this.suggestionReportData
      this.suggestionReportRevisions = res;
    });
  }

  getRiskAssessment() {
    this._ApiService.getRiskAssessment(this.suggestionReportData).subscribe((data) => {
      this.riskAssessmentData = data.pop();
      if (this.riskAssessmentData !== undefined) {
        this.suggestionReportRevision.revision = this.riskAssessmentData.version
      }
    })
  }

  openPrintSuggestionReportDialog() {
    const iqcpPrintsDialog = this.dialog.open(PrintSuggestionReportComponent,{
      disableClose: true,
      height: '400px',
      width: '600px',
      data: this.suggestionReportRevision,
      panelClass: 'iqcp-revision-dialog'
    });

    iqcpPrintsDialog.afterClosed().subscribe(result => {
      setTimeout(() => {
        this._ApiService.getSuggestionReportRevision(this.suggestionReportData).subscribe((res: any) => {
          this.suggestionReportRevisions = res;
        });
      }, 500);
    });
  }

}
