import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qcp-dialog',
  templateUrl: './qcp-dialog.component.html',
  styleUrls: ['./qcp-dialog.component.scss']
})
export class QcpDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
