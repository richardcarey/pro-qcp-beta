import { NotificationService } from '../../../../services/notification.service'
import { element } from 'protractor';
import {
  Component,
  OnInit,
  AfterContentInit,
  AfterViewInit,
  Input,
  Output,
  IterableDiffers
} from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';
import { AcceptabilityMatrix } from 'src/app/interface/acceptability-matrix';
import { ApiService } from 'src/app/services/api.service';
import {
  AcceptabilityData,
} from 'src/app/interface/acceptability-data';
import { Subject, Observable } from "rxjs";
import { DataService } from './../../../../services/data.service';
import { MatDialog } from '@angular/material/dialog';
import { SeverityInfoComponent } from 'src/app/dialogs/severity-info/severity-info.component';
import { ProbabilityInfoComponent } from 'src/app/dialogs/probability-info/probability-info.component';

@Component({
  selector: 'app-risk-acceptability-matrix',
  templateUrl: './risk-acceptability-matrix.component.html',
  styleUrls: ['./risk-acceptability-matrix.component.scss'],
})


export class RiskAcceptabilityMatrixComponent
  implements OnInit, AfterContentInit, AfterViewInit {
  displayedColumns: string[] = ['probability'];
  displayedColumnsFirst: string[] = ['severity'];
  dataColumns: any = [];
  acceptabilityMatrix: AcceptabilityData;
  dataSource: AcceptabilityMatrix[] = [];
  @Input() programModule: any;
  constructor(private apiService: ApiService, private notifyService : NotificationService, private _DataService: DataService,
    private dialog: MatDialog) {}
  probabilityArray = ['Frequent', 'Probable', 'Occasional', 'Remote', 'Improbable']
  @Input() events: Observable<void>;
  eventsSubscription: any
  subscription;
  acceptabilityChangeSub;
  @Input() showSaveButton: boolean = false;
  ngAfterContentInit(): void {}

  ngAfterViewInit(): void {}

  ngOnInit(): void {
    this.apiService.getToken();
    this.getAcceptabilityData();
    if (this.events !== undefined) {
      this.eventsSubscription = this.events.subscribe(() => {
        this.postAcceptabilityMatrix()
      });
    }
    this.acceptabilityChangeSub = this._DataService.acceptabilityMatrixChanged.subscribe((acceptabilityMatrix) => {
      if (acceptabilityMatrix.items !== undefined) {
        this.formatAcceptabilityMatrixTable([acceptabilityMatrix]);
      }
      
    });
  }
  ngOnDestroy() {
    if (this.eventsSubscription != undefined) {
      this.eventsSubscription.unsubscribe();
    }
    
    if (this.subscription != undefined) {
      this.subscription.unsubscribe();
    }

    if (this.acceptabilityChangeSub != undefined) {
      this.acceptabilityChangeSub.unsubscribe();
    }
  }
  
  ToggleAcceptability(e, index, value, element) {
    const matCell: HTMLElement = document.getElementById(index) as HTMLElement;
    if (matCell.innerHTML.trim() == 'Unacceptable') {
      matCell.style.backgroundColor = '#7FBA00';
      matCell.innerHTML = 'Acceptable';
      value = '1';
    } else {
      matCell.style.backgroundColor = '#f04e1f';
      matCell.innerHTML = 'Unacceptable';
      value = '0';
    }
    this.updateAcceptabilityMatrix(index, value, element.iqcp_module);
  }

  getAcceptabilityData() {
    this.apiService.getAcceptabilityMatrix(this.programModule).subscribe((data) => {
    this.formatAcceptabilityMatrixTable(data);
    });
  }

  // Update Acceptability Matrix data
  updateAcceptabilityMatrix(index, value, module_id) {
    let indexArr = index.split('_');
    let importance = indexArr[0];
    let probabilityIndex = indexArr[1];
    this.acceptabilityMatrix.created = Date.now();
    for (let i=0; i < this.acceptabilityMatrix.items.length; i++) {
      if (this.acceptabilityMatrix.items[i].frequency == this.probabilityArray[probabilityIndex] 
        && this.acceptabilityMatrix.items[i].importance.toLowerCase() == importance) {
          this.acceptabilityMatrix.items[i].acceptance = value;
      }
    }
  }

   // Submit updated Acceptability Matrix data via http service
   postAcceptabilityMatrix() {
    this._DataService.acceptabilityMatrixData = this.acceptabilityMatrix;
    this.apiService
    .createAcceptabilityMatrix(this.acceptabilityMatrix)
    .subscribe((data) => {
      this.showToaster('Acceptability Matrix updated!', 'Acceptability Matrix');
      this._DataService.changeAcceptabilityMatrix(this.acceptabilityMatrix);
    });
   }
   showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }

  // Return formatted data for md table
  formatAcceptabilityMatrixTable(data) {
    this.acceptabilityMatrix = data.pop();
    if (this.acceptabilityMatrix.order_id == "") {
      this.acceptabilityMatrix.order_id = this.programModule;
    }
    this._DataService.acceptabilityMatrixData = this.acceptabilityMatrix;
    let frequency = [];
    const acceptabilityDataFormat = [];

    for (var i = 0; i < this.acceptabilityMatrix.items.length; i++) {
      this.displayedColumns.push(
        this.acceptabilityMatrix.items[i].importance.toLowerCase()
      );
      frequency.push(this.acceptabilityMatrix.items[i].frequency);
    }
    
    frequency = [...new Set(frequency)];
    this.displayedColumns = [...new Set(this.displayedColumns)];
    let count = 0;
    for (let item of frequency) {
      acceptabilityDataFormat.push({ probability: item });
      for (var i = 0; i < this.acceptabilityMatrix.items.length; i++) {
        acceptabilityDataFormat[
          count
        ].iqcp_module = this.acceptabilityMatrix.items[i].iqcp_module;
        if (item == this.acceptabilityMatrix.items[i].frequency) {
          switch (this.acceptabilityMatrix.items[i].importance.toLowerCase()) {
            case 'negligible':
              acceptabilityDataFormat[
                count
              ].negligible = this.acceptabilityMatrix.items[i].acceptance;
              break;
            case 'minor':
              acceptabilityDataFormat[
                count
              ].minor = this.acceptabilityMatrix.items[i].acceptance;
              break;
            case 'serious':
              acceptabilityDataFormat[
                count
              ].serious = this.acceptabilityMatrix.items[i].acceptance;
              break;
            case 'critical':
              acceptabilityDataFormat[
                count
              ].critical = this.acceptabilityMatrix.items[i].acceptance;
              break;
            case 'catastrophic':
              acceptabilityDataFormat[
                count
              ].catastrophic = this.acceptabilityMatrix.items[i].acceptance;
              break;
          }
        }
      }
      count++;
    }
    this.dataSource = acceptabilityDataFormat;
  }

  resetToDefault() {
    this.acceptabilityMatrix.items = [
      {frequency: "Frequent", importance: "Negligible", acceptance: "0"},
      {frequency: "Probable", importance: "Negligible", acceptance: "1"},
      {frequency: "Occasional", importance: "Negligible", acceptance: "1"},
      {frequency: "Remote", importance: "Negligible", acceptance: "1"},
      {frequency: "Improbable", importance: "Negligible", acceptance: "1"},
      {frequency: "Frequent", importance: "Minor", acceptance: "0"},
      {frequency: "Probable", importance: "Minor", acceptance: "0"},
      {frequency: "Occasional", importance: "Minor", acceptance: "1"},
      {frequency: "Remote", importance: "Minor", acceptance: "1"},
      {frequency: "Improbable", importance: "Minor", acceptance: "1"},
      {frequency: "Frequent", importance: "Serious", acceptance: "0"},
      {frequency: "Probable", importance: "Serious", acceptance: "0"},
      {frequency: "Occasional", importance: "Serious", acceptance: "0"},
      {frequency: "Remote", importance: "Serious", acceptance: "1"},
      {frequency: "Improbable", importance: "Serious", acceptance: "1"},
      {frequency: "Frequent", importance: "Critical", acceptance: "0"},
      {frequency: "Probable", importance: "Critical", acceptance: "0"},
      {frequency: "Occasional", importance: "Critical", acceptance: "0"},
      {frequency: "Remote", importance: "Critical", acceptance: "0"},
      {frequency: "Improbable", importance: "Critical", acceptance: "1"},
      {frequency: "Frequent", importance: "Catastrophic", acceptance: "0"},
      {frequency: "Probable", importance: "Catastrophic", acceptance: "0"},
      {frequency: "Occasional", importance: "Catastrophic", acceptance: "0"},
      {frequency: "Remote", importance: "Catastrophic", acceptance: "0"},
      {frequency: "Improbable", importance: "Catastrophic", acceptance: "1"}
    ]
    this.formatAcceptabilityMatrixTable([this.acceptabilityMatrix])
  }

  severityInfo() {
    this.dialog.open(SeverityInfoComponent,
      {
        width: '80%'
      });
  }

  probabilityInfo() {
    this.dialog.open(ProbabilityInfoComponent,
      {
        width: '400px'
      });
  }
}


