import { Component, OnInit } from '@angular/core';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';

import { Inject } from '@angular/core';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
  checkAcceptabilityPost: boolean
  eventsSubject: Subject<void> = new Subject<void>();
  
  constructor(
     @Inject(MAT_DIALOG_DATA) public userData: any
  ) { }
  emitAcceptabilityEventToChild() {
    this.eventsSubject.next();
  }
  ngOnInit() {  }
}

