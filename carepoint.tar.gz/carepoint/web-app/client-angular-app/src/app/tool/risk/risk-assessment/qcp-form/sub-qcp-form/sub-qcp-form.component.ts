import { Qcp } from '../../../../../interface/qcp';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ApiService } from '../../../../../services/api.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs'
import { DataService } from './../../../../../services/data.service';
@Component({
  selector: 'app-sub-qcp-form',
  templateUrl: './sub-qcp-form.component.html',
  styleUrls: ['./sub-qcp-form.component.scss']
})
export class SubQcpFormComponent implements OnInit {
  @Input() riskQCPList;
  checked;
  qcpData: Qcp [];
  @Input() accreditingAgency;
  QCPForm: FormGroup;
  @Input() qcpIds: any [];
  @Output()QcpData: EventEmitter<any> = new EventEmitter<number>();
  @Input() qcptPost: Observable<void>;
  eventsSubscription: any;
  qcpSubscription: any;
  frequencyOptions: any [];
  isQcpEmpty: boolean;
  statusTooltipText:string = `Indicate here if the suggested risk mitigation action (QCP) is currently implemented, should be considered for the future, or if it is not applicable.  Any QCP’s selected as ‘Current Practice’ will appear on the IQCP Report and those selected ‘Consider for Future’ will appear on the Suggestion Report.`;
  actionTooltipText:string = `The fields below capture each mitigation action (QCP) currently implemented and also those that could be effective in the future.  Fields have been pre-filled for convenience, but each field can be customized/edited and you can add as many fields as you need for additional QCP’s.`;
  frequencyTooltipText:string = 'Input the appropriate time increment';
  acceptanceCriteriaTooltipText:string = 'Describe how you know when the risk mitigation action (QCP) has been deployed effectively';
  displayedColumns: string[] = ['position', 'action', 'citation', 'frequency', 'criteria'];
  dataSource:any = [];
  currentPracticeOptions = [
    {value: 'Current Practice'},
    {value: 'Consider for Future'},
    {value: 'Not Applicable'}
  ];
  dataCheckbox = [
    {title: 'Written Policy', value: false},
    {title: 'Direct observation', value: true},
    {title: 'Quiz', value: false},
    {title: 'Blind samples', value: false},
    {title: 'Didactic', value: false},
    {title: 'Direct observation(Maintanence)', value: true},
    {title: 'Problem solving', value: false},
    {title: 'Monitoring results', value: false},
  ];
  field_names = [
    'risk_id',
    'id',
    'QCP_ID',
    'Frequency',
    'Criteria',
    'activity_performance',
    'current_practice',
    'current_practice_options',
    'CAP_Citation',
    'CAP_txt',
    'TJC_Citation',
    'TJC_txt',
    'CLIA_Citation',
    'CLIA_txt',
    'COLA_Citation',
    'COLA_txt',
    'Add_to_QCP_Table',
    'Action',
  ];
  constructor(private _ApiService: ApiService, private fb: FormBuilder, private _DataService: DataService) { }

  ngOnInit(): void {
    if (this.riskQCPList != undefined) {
      this.buildForm();
    }
    else {
      this.isQcpEmpty = true;
    }
    if (this.qcptPost !== undefined) {
      this.eventsSubscription = this.qcptPost.subscribe((riskIds) => {
        this.onSubmitQCP(riskIds);
      });
    }
    this.qcpSubscription = this._DataService.currentQcpChange.subscribe(currentQCp => {
      this.updateQcpCitation(currentQCp);
    });
  }
  
  ngOnDestroy() {
    this.eventsSubscription.unsubscribe();
  }

  // Create a QCP form
  public buildForm() {
		this.QCPForm = this.fb.group({});
    for (let i= 0; i < this.riskQCPList.qcps.length; i++) {
      for (let a = 0; a < this.field_names.length; a++) {
        this.QCPForm.addControl(this.field_names[a] + i, this.fb.control(this.riskQCPList.qcps[i][`${this.field_names[a]}`], Validators.required));
        this.riskQCPList.qcps[i].index_row = i;
        if (this.riskQCPList.qcps[i].citation == '') {
          this.filterCitationsByAccreditingAgency(this.riskQCPList.qcps[i]);
        }
      }
    }

    // Check if there are any qcp items
    if (Object.keys(this.QCPForm.value).length === 0) {
      this.isQcpEmpty = true;
    }

    // assign riskQCPList to table data
    this.dataSource = this.riskQCPList.qcps;

    // Add new QCP
    this.AddNewQCPRow();
  }

   // Format and POST QCP changes to service
  onSubmitQCP(riskIds) {
    for (let i = 0; i < this.riskQCPList.qcps.length; i++) {
      for (let a = 0; a < this.field_names.length; a++) {
        this.riskQCPList.qcps[i][`${this.field_names[a]}`] = this.QCPForm.value[`${this.field_names[a] + i}`]
      }
    }
    if (this.riskQCPList.risk_id.indexOf(riskIds)) {
      this.QcpData.emit(this.riskQCPList);
    }
  }

  AddNewQCPRow(updateQCPList = false) {
    let formLength = this.dataSource.length;
    let lastQcpId = this.assignNewQcpID();
    this.dataSource.push({index_row: formLength, risk_id: this.riskQCPList.risk_id, QCP_ID: lastQcpId, isNew: true, citation: ''})
    this.dataSource = [... this.dataSource];
    for (let a = 0; a < this.field_names.length; a++) {
      this.QCPForm.addControl(
        this.field_names[a] + formLength, this.fb.control(this.dataSource[this.dataSource.length - 1][this.field_names[a]],
        Validators.required));
    }
    if (updateQCPList) {
      this.riskQCPList.qcps.push({index_row: formLength, risk_id: this.riskQCPList.risk_id, QCP_ID: lastQcpId, isNew: true, citation: ''})
    }
  }

  assignNewQcpID() {
    let newQcpId: any;
    newQcpId = (this.qcpIds.length) ? parseInt(this.qcpIds[this.qcpIds.length - 1]) + 10 : 1010;
    newQcpId = String(newQcpId);
    this.qcpIds.push(newQcpId);
    return newQcpId;
  }

  // Prevent adding new QCP rows by Enter key
  handleEnterKeyPress(e) {
    if (e.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  }

  openToolTipDialog(toolTipText, title, width) {
    const dialogRef = this._DataService.openToolTipDialog(toolTipText, title, width);
  }

  updateQcpCitation(qcp) {
    for (let i = 0; i < this.riskQCPList.qcps.length; i++) {
      if (this.riskQCPList.qcps[i].QCP_ID == qcp.QCP_ID && this.riskQCPList.qcps[i].risk_id == qcp.risk_id) {
        this.riskQCPList.qcps[i].citation = encodeURI(qcp.citation);
      }
    }
  }

  openCitationDialog(qcp, title, width) {
    const dialogRef = this._DataService.openCitationpDialog(qcp, title, width);
  }

  filterCitationsByAccreditingAgency(qcp) {
    let qcp_citation = '';
    if ((qcp[`${this.accreditingAgency}` + '_Citation'] != "" && qcp[`${this.accreditingAgency}` + '_txt'] != "") &&
    qcp[`${this.accreditingAgency}` + '_Citation'] != undefined && qcp[`${this.accreditingAgency}` + '_txt'] != undefined) {
      qcp_citation = qcp[`${this.accreditingAgency}` + '_Citation'] + '<br>';
      qcp_citation += qcp[`${this.accreditingAgency}` + '_txt'];
    }
    qcp.citation = qcp_citation; 
  }
}
