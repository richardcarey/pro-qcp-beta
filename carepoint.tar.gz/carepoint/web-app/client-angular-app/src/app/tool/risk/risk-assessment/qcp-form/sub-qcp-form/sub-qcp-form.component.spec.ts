import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubQcpFormComponent } from './sub-qcp-form.component';

describe('SubQcpFormComponent', () => {
  let component: SubQcpFormComponent;
  let fixture: ComponentFixture<SubQcpFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubQcpFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubQcpFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
