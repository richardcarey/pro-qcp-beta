import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-reference',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.scss']
})
export class ReferenceComponent implements OnInit {

  public referenceParam;
  public riskData;
  public references;
  constructor(private apiService: ApiService,
              private dataService: DataService,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.dataService.itemChange.next('Reference');
    this.route.paramMap.subscribe(params => {
      this.referenceParam = params.get('referenceData');
      this.getReferences();
    });
  }

  getAcceptedReferences(accreditingAgencies) {
    let acceptedReferences = [];
    let includeReferences = [];
    let listAgencies = ["CAP", "TJC", "COLA", "CLIA"];
    accreditingAgencies.forEach(accreditingAgency => {
      if(accreditingAgencies.includes('Other')){
        if(listAgencies.includes(accreditingAgency)){
          includeReferences.push(accreditingAgency);
        }
      } else {
      acceptedReferences = acceptedReferences.concat(this.references.filter(reference => (reference.description.includes(accreditingAgency) || reference.title.includes(accreditingAgency))));
      }
    });

    if(accreditingAgencies.includes('Other')){
      return acceptedReferences = this.getOtherReferences(listAgencies, includeReferences, acceptedReferences);
    }
      return acceptedReferences;
  }

  getOtherReferences(listAgencies, includeReferences, acceptedReferences){    
    let excludeAgencies = listAgencies.filter(x => !includeReferences.includes(x));
    acceptedReferences = this.references;
    if (excludeAgencies.length > 0){
      excludeAgencies.forEach(excludeAgency => {
        acceptedReferences = acceptedReferences.filter(({title}) => !title.includes(excludeAgency));
        acceptedReferences = acceptedReferences.filter(({description}) => !description.includes(excludeAgency));
      })
    }
    return acceptedReferences;
  }

  getReferences() {
    this.apiService.getReferences().subscribe(res => {
      this.references = res;
      this.getRiskData();
    });
  }

  getRiskData() {
    this.apiService.getRiskAssessment(this.referenceParam).subscribe(res => {
      this.riskData = res;
      if (!this.riskData.references) {
        this.riskData.references = this.getAcceptedReferences(res[0].accrediting_agency);
      }
    });
  }

}
