import { AuthService } from './services/auth.service';
import { AuthInterceptor } from './services/auth.interceptor';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatMenuModule } from '@angular/material/menu';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { AccountCentralComponent } from './account-central/account-central.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import {MatTooltipModule} from '@angular/material/tooltip';
import { ToolComponent } from './tool/tool.component';
import {MatRadioModule} from '@angular/material/radio';

import { ProgramComponent } from './tool/program/program.component';
import { RiskComponent } from './tool/risk/risk.component';
import { QualityChecklistComponent } from './tool/quality-checklist/quality-checklist.component';
import { IqcpComponent } from './tool/iqcp/iqcp.component';
import { ReferenceComponent } from './tool/reference/reference.component';
import { HelpComponent } from './tool/help/help.component';
import { DialogComponent } from './tool/risk/dialog/dialog.component';
import { ApiService } from './services/api.service';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import {MatCardModule} from '@angular/material/card';
import { AddRiskComponent } from './tool/risk/risk-assessment/add-risk/add-risk.component';
import { ShowProgressComponent } from './tool/risk/risk-assessment/show-progress/show-progress.component';
import { RiskFishboneComponent } from './tool/risk/risk-assessment/risk-fishbone/risk-fishbone.component';
import { RiskAssessmentComponent } from './tool/risk/risk-assessment/risk-assessment.component';
import { RiskAcceptabilityMatrixComponent } from './tool/risk/risk-assessment/risk-acceptability-matrix/risk-acceptability-matrix.component';
import { QcpFormComponent } from './tool/risk/risk-assessment/qcp-form/qcp-form.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { QcpDialogComponent } from './tool/risk/risk-assessment/qcp-form/qcp-dialog/qcp-dialog.component';
import { ToastrModule } from 'ngx-toastr';
import { SubQcpFormComponent } from './tool/risk/risk-assessment/qcp-form/sub-qcp-form/sub-qcp-form.component';
import {MatDividerModule} from '@angular/material/divider';
import { MatGridListModule } from '@angular/material/grid-list';
import { AccountEditComponent } from './account-central/account-edit/account-edit.component';
import { OverviewComponent } from './tool/overview/overview.component';
import { LoadingPopupComponent } from './dialogs/loading-popup/loading-popup.component';
import { FooterComponent } from './footer/footer.component';
import { InfoComponent } from './dialogs/info/info.component';
import { SeverityInfoComponent } from './dialogs/severity-info/severity-info.component';
import { ProbabilityInfoComponent } from './dialogs/probability-info/probability-info.component';
import { LocationsDialogComponent } from './account-central/locations-dialog/locations-dialog.component';
import { UsersDialogComponent } from './account-central/users-dialog/users-dialog.component';
import { ModulesDialogComponent } from './account-central/modules-dialog/modules-dialog.component';
import { PrintQcpDialogComponent } from './dialogs/print-qcp-dialog/print-qcp-dialog.component';
import { SuggestionReportComponent } from './tool/risk/risk-assessment/suggestion-report/suggestion-report.component';
import { PrintSuggestionReportComponent } from './dialogs/print-suggestion-report/print-suggestion-report.component';
import { FishboneGeneratorComponent } from './tool/fishbone-generator/fishbone-generator.component';
import { EditCitationComponent } from './dialogs/edit-citation/edit-citation.component';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { UnauthorizedComponent } from './tool/unauthorized/unauthorized.component';
import { UnauthenticatedComponent } from './tool/unauthenticated/unauthenticated.component';
@NgModule({
  declarations: [
    AppComponent,
    QcpFormComponent,
    RiskAcceptabilityMatrixComponent,
    ProgramComponent,
    RiskComponent,
    QualityChecklistComponent,
    IqcpComponent,
    ReferenceComponent,
    HelpComponent,
    DialogComponent,
    AccountCentralComponent,
    AddRiskComponent,
    ShowProgressComponent,
    RiskFishboneComponent,
    ToolComponent,
    RiskAssessmentComponent,
    QcpDialogComponent,
    SubQcpFormComponent,
    AccountEditComponent,
    OverviewComponent,
    LoadingPopupComponent,
    FooterComponent,
    InfoComponent,
    SeverityInfoComponent,
    ProbabilityInfoComponent,
    LocationsDialogComponent,
    UsersDialogComponent,
    ModulesDialogComponent,
    PrintQcpDialogComponent,
    SuggestionReportComponent,
    PrintSuggestionReportComponent,
    FishboneGeneratorComponent,
    EditCitationComponent,
    UnauthorizedComponent,
    UnauthenticatedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatInputModule,
    ReactiveFormsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTabsModule,
    MatMenuModule,
    FlexLayoutModule,
    MatTooltipModule,
    ToastrModule.forRoot(),
    MatProgressSpinnerModule,
    MatProgressBarModule,
    FormsModule,
    MatSelectModule,
    MatCardModule,
    MatExpansionModule,
    MatDividerModule,
    MatGridListModule,
    MatRadioModule,
    AngularEditorModule
  ],
  providers: [
    ApiService,
    {
      provide: MatDialogRef,
      useValue: {}
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
      deps: [ApiService]
    }],
  bootstrap: [AppComponent],
  entryComponents: [LoadingPopupComponent, InfoComponent, SeverityInfoComponent, ProbabilityInfoComponent]
})
export class AppModule {}
