import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { PlatformLocation } from '@angular/common';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  baseUrl: string;
  data: any;
  constructor(private _http: HttpClient, private platformLocation: PlatformLocation, private _DataService: DataService) {
    
    // Base url
    this.baseUrl = (platformLocation as any).location.origin;
  }
  public getUserData(): Observable<any> {
    return new Observable(observer => {
      if (this._DataService.currentUserData) {
        this._DataService.currentUserRole = this._DataService.currentUserData.roles[1];
        observer.next(this._DataService.currentUserData);
        return observer.complete();
      }

      const http$ = this._http.get<any>(this.baseUrl+"/user_auth" , {responseType: 'json', withCredentials: true});
      http$.pipe(
        map(res => res),
        catchError(err => {
            observer.next(this.data);
            observer.complete();
            return throwError(err);
        })
      )
      .subscribe(
        res => this.setObserverData(observer, res)
      );
    });
  }

  public setObserverData(observer, data){
    this._DataService.currentUserRole = data.roles[1];
    this._DataService.currentUserData = data
    this.data = data || [];
    observer.next(this.data);
    observer.complete();
  };
}