import { AcceptabilityData } from './../interface/acceptability-data';
import { RiskAssessment } from './../interface/risk-assessment';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from './api.service'
import { NotificationService } from './/notification.service'
import {  Router } from '@angular/router';
import { InfoComponent } from '../dialogs/info/info.component'
import { EditCitationComponent } from '../dialogs/edit-citation/edit-citation.component';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private qcpItemUpdated = new BehaviorSubject<any>({});
  private programParam = new BehaviorSubject<string>('');
  private programModule = new BehaviorSubject<any>({});
  private acceptabilityMatrix = new BehaviorSubject<any>({});
  acceptabilityMatrixChanged = this.acceptabilityMatrix.asObservable();
  public routerMessage = new BehaviorSubject<string>('');
  public routePermission = new BehaviorSubject<any>(false);
  currentQcpChange = this.qcpItemUpdated.asObservable();
  currentProgramModule = this.programModule.asObservable();
  addedRisk = new BehaviorSubject<any>(false);
  addedNewRisk = this.addedRisk.asObservable();
  currentProgramParam = this.programParam.asObservable();
  triggerRiskSubmitEvent = new BehaviorSubject<any>(false);
  qcpSavedEvent = new BehaviorSubject<any>(false);
  currentQcpSaved = this.qcpSavedEvent.asObservable();
  categoryChange = new BehaviorSubject<any>(false);
  currentCategory = this.categoryChange.asObservable();
  currentRiskEvent = this.triggerRiskSubmitEvent.asObservable();
  itemChange = new BehaviorSubject<any>(false);
  currentItem = this.itemChange.asObservable();
  currentMessage = this.routerMessage.asObservable();
  currentRoutePermission = this.routePermission.asObservable();
  currentUserRole;
  currentUserData;

  acceptabilityMatrixData: AcceptabilityData;
  constructor(
    private _ApiService: ApiService,
    private _NotificationService: NotificationService,
    private Router: Router,
    public dialog: MatDialog,
    ) { }


  changeProgramParam(programParam: string) {
    this.programParam.next(programParam);
  }
  
  changeQcp(currentQCp: {}) {
    this.qcpItemUpdated.next(currentQCp);
  }

  changeProgramModule(programModule: RiskAssessment) {
    this.programModule.next(programModule);
  }

  changeAddedRiskModule(addedRisk: boolean) {
    this.addedRisk.next(addedRisk);
  }

  changeAcceptabilityMatrix(acceptabilityMatrix: AcceptabilityData) {
    this.acceptabilityMatrix.next(acceptabilityMatrix);
  }

  changeQcpSavedEvent(qcpSavedEvent: boolean) {
    this.qcpSavedEvent.next(qcpSavedEvent);
  }

  changeRiskEvent(triggerRiskSubmitEvent: boolean) {
    this.triggerRiskSubmitEvent.next(triggerRiskSubmitEvent);
  }
  
  postProgramData(programData) {
    this._ApiService.createRiskAssessment(programData).subscribe((data) => {
      this.changeRiskEvent(false);
      this._NotificationService.showSuccess('Successfully updated Risk Assessment', 'Risk Assessment')
    });
  }
  jumpToMenuTrigger(category, orderId) {
    this.Router.navigate(['/risk/' + orderId + '/risk-assessment/' + orderId + '/' + category]);
  }

  jumpToPrint(orderId) {
    this.Router.navigate(['/iqcp/' + orderId]);
  }
  changeCategory(category) {
    this.categoryChange.next(category);
  }
  
  jumpToQualityChecklist(orderId) {
    this.Router.navigate(['/quality-checklist/' + orderId]);
  }

  calculateRiskAcceptability(severity, probability) {
    let acceptabilityitems = this.acceptabilityMatrixData.items;
    let filteredItem = acceptabilityitems.filter((item) => {
      if (item.frequency == probability && item.importance == severity) {
        return item;
      }
    })

    return filteredItem;
  }

  postQualityData(qualityData) {
    this._ApiService.createRiskAssessment(qualityData).subscribe((data) => {
      this._NotificationService.showSuccess('Successfully updated Risk Assessment', 'Risk Assessment')
    });
  }

  openToolTipDialog(toolTipText, title, width) {
    const dialogRef = this.dialog.open(InfoComponent,
    {
      height: 'auto',
      width: width,
      data: {
        title: title,
        paragraphOne: toolTipText
      }
    });
  }
  
  openCitationpDialog(object, title, width) {
    const dialogRef = this.dialog.open(EditCitationComponent,
    {
      height: 'auto',
      width: width,
      data: {
        title: title,
        object: object
      }
    });
  }

  setRouterMessage(message: string) {
    this.routerMessage.next(message);
  }

  setRoutePermission(canAccess: boolean) {
    this.routePermission.next(canAccess);
  }
}
