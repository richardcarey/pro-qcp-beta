import { Injectable } from '@angular/core';
export interface InternalStateType {
  [key: string]: any;
}
@Injectable({
  providedIn: 'root'
})
export class StateService {
  // tslint:disable-next-line:variable-name
  public _scope: InternalStateType = {};
  constructor() {
    //
  }
  public get(prop?: any) {
    if (this._scope.hasOwnProperty(prop)) {
      if (this.isPrimitive(this._scope[prop])) {
        return this._scope[prop];
      } else {
        return JSON.parse(JSON.stringify(this._scope[prop]));
      }
    } else {
      return null;
    }
  }

  /**
   * Returns reference of element, not its copy
   * @param prop - name of requested property
   */
  public getReference(prop) {
    if (this._scope.hasOwnProperty(prop)) {
      return this._scope[prop];
    } else {
      return null;
    }
  }

  public set(prop: string, value: any) {
    return (this._scope[prop] = value);
  }

  public isPrimitive(value) {
    return value !== Object(value);
  }
}
