import { IqcpPdfData } from './../interface/iqcp-pdf-data';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import {AcceptabilityData} from '../interface/acceptability-data'
import { Qcp } from '../interface/qcp'
import {RiskAssessment} from '../interface/risk-assessment'
import {PlatformLocation } from '@angular/common';
import { UserModulesListData } from '../interface/user-modules-list-data';
import { AccountDetailsData } from '../interface/account-details';



@Injectable({
  providedIn: 'root'
})
export class ApiService {
  baseUrl: string;
  token: string
  accountDetails: Array<any> ;
  constructor(private http: HttpClient, private platformLocation: PlatformLocation) {

    // Base url
    this.baseUrl = (platformLocation as any).location.origin;
  }

  // POST Acceptability Matrix
  createAcceptabilityMatrix(data): Observable<AcceptabilityData> {
    return this.http
      .post<AcceptabilityData>(
        this.baseUrl +
          '/api/carepoint_acceptability_matrix?_format=json',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET Acceptability Matrix
  getAcceptabilityMatrix(module_id: number): Observable<AcceptabilityData[]> {
    return this.http
      .get<AcceptabilityData[]>(
        this.baseUrl +
          '/api/carepoint_acceptability_matrix/' + module_id + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  
  // GET User Modules/Orders 
  getUserModulesList(): Observable<UserModulesListData> {
    return this.http
      .get<UserModulesListData>(
        this.baseUrl + '/get-user-orders' + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

    // GET User Modules/Orders 
    getModulesList(): Observable<UserModulesListData> {
      return this.http
        .get<UserModulesListData>(
          this.baseUrl + '/get-user-modules' + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

  // GET Countries List
  getCountriesList(): Observable<any> {
    return this.http
      .get<any>(
        this.baseUrl + '/countries_list' + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET states List
  getStatesList(country_code): Observable<any> {
    return this.http
      .get<any>(
        this.baseUrl + '/states_list/' + country_code + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET states List
  setOrderLocation(data): Observable<AccountDetailsData> {
    return this.http
      .post<AccountDetailsData>(
        this.baseUrl +
          '/set-order-location',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET Account Details
  getAccountDetails(): Observable<AccountDetailsData> {
    return this.http
      .get<AccountDetailsData>(
        this.baseUrl + '/account-details-rest' + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // POST Account Details 
  updateAccountDetails(data): Observable<AccountDetailsData> {
    return this.http
      .post<AccountDetailsData>(
        this.baseUrl +
          '/account_update',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

   // Add User To location
  addUserToLocation(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/add_user_to_location',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  //add_new_user
  addNewUser(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/add_new_user',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }


 // Update user data or location
  updateUserDataOrLocation(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/update_user_data_or_location',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

   // remove user
   removeUser(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/remove_user',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
    // Get Users By location
  checkIsUsernameValid(name): Observable<any> {
    return this.http
      .get<any>(
        this.baseUrl + '/check-is-username-valid/'+ name + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  // Get Users By location
  checkIsEmailUsed(email): Observable<any> {
    return this.http
      .get<any>(
        this.baseUrl + '/check-is-email-used/'+ email + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  // Get Users By location
  getUsersByLocation(): Observable<any> {
    return this.http
      .get<any>(
        this.baseUrl + '/get_users_from_location' + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
    // Get Users By Organization
    getUsersByOrganization(): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/get_users_from_organization' + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }
   // ADD Account Details
  addIqcpLocation(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/iqcp-location-add',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  updateIqcpLocation(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/iqcp-location-update',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
  deleteIqcpLocation(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/iqcp-location-delete',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }
 // GET Account Details
 getIqcpLocation(): Observable<any> {
  return this.http
    .get<any>(
      this.baseUrl + '/iqcp-locations-list' + '?_format=json',{withCredentials: true}
    )
    .pipe(retry(1), catchError(this.errorHandl));
  }

  ///get_associated_locations
  getAssociatedLocations(){
    return this.http
    .get<any>(
      this.baseUrl + '/get_associated_locations' + '?_format=json',{withCredentials: true}
    )
    .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET Token
  getToken() {
    return this.http.get(this.baseUrl + '/rest/session/token', {withCredentials: true, responseType: 'text'})
    .subscribe((data) => {
      this.token = data;
    })
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
  
  // GET Risk Assessment
  getRiskAssessment(module_id: string): Observable<RiskAssessment[]> {
    return this.http
      .get<RiskAssessment[]>(
        this.baseUrl +
          '/api/carepoint_risk_assesment_question/' + module_id + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET Risk Assessment
  getRiskAssessmentTemplate(module_id: string): Observable<RiskAssessment[]> {
    return this.http
      .get<RiskAssessment[]>(
        this.baseUrl +
          '/api/carepoint_risk_assessment_template/' + module_id + '?_format=json',{withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // POST Risk Assessment
  createRiskAssessment(data): Observable<RiskAssessment> {
    return this.http
      .post<RiskAssessment>(
        this.baseUrl +
          '/api/carepoint_risk_assesment_question?_format=json',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET QCP
  getQCP(risk_id: {}): Observable<Qcp []> {
    return this.http
      .post<Qcp []>(
        this.baseUrl +
          '/api/carepoint_get_qcp?_format=json',JSON.stringify(risk_id), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // POST QCP
  createQCP(data): Observable<Qcp> {
    return this.http
      .post<Qcp>(
        this.baseUrl +
          '/api/carepoint_qcp_questions?_format=json',
        JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  getSelectedOrder(order_number: string, endpoint: string) {
    return this.http.get<UserModulesListData>( this.baseUrl + '/' + endpoint + '/' + order_number + '?_format=json',
    {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  getPDFIQCP(order_number: string) : Observable<IqcpPdfData> {
    return this.http.get<IqcpPdfData>( this.baseUrl + '/api/carepoint_pdf_iqcp/' + order_number + '?_format=json',
    {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl))
  }

  getPDFSuggestionReport(order_number: string) : Observable<IqcpPdfData> {
    return this.http.get<IqcpPdfData>( this.baseUrl + '/api/carepoint_pdf_iqcp/' + order_number + "/get-suggestion-report" +'?_format=json',
    {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl))
  }

  // Add Iqcp Revision
  createIqcpRevision(data): Observable<any> {
    return this.http
      .post<any>(
        this.baseUrl +
          '/save_iqcp_revision',
          JSON.stringify(data), {withCredentials: true}
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

    // Update Iqcp Revision File
    updateIqcpRevisionFile(data): Observable<any> {
      return this.http
        .post<any>(
          this.baseUrl +
            '/update_iqcp_revision_file',
            JSON.stringify(data), {withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    // Suggestion Report Revision
    createSuggestionReportRevision(data): Observable<any> {
      return this.http
        .post<any>(
          this.baseUrl +
            '/save_suggestion_report_revision',
            JSON.stringify(data), {withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }
    // Update Suggestion Report Revision
    updateSuggestionReportRevisionFile(data): Observable<any> {
      return this.http
        .post<any>(
          this.baseUrl +
            '/update_suggestion_report_revision_file',
            JSON.stringify(data), {withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    // Store Fishbone Diagrm
    storeFishboneDiagram(data): Observable<any> {
      return this.http
        .post<any>(
          this.baseUrl +
            '/create_fishbone_diagram',
            JSON.stringify(data), {withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    // Get iqcp by order item id
    getIqcpRevision(order_item_id): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/get_iqcp_revision/'+ order_item_id + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    //get_suggestion_report_revision
    getSuggestionReportRevision(order_item_id): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/get_suggestion_report_revision/'+ order_item_id + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }
    //check_is_module_expired

    checkIsModuleExpired(order_item_id): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/check_is_module_expired/'+ order_item_id + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    getReferences() {
      return this.http.get<UserModulesListData>( this.baseUrl + '/get_references?_format=json',
      {withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    //get-riskassesment-id
    getRiskAssesmentIdByOrderItemId (order_item_id): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/get-riskassesment-id/'+ order_item_id + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }

    //get_fishbone_by_order_item_id
    getFishboneByRiskAssesment (risk_assesment): Observable<any> {
      return this.http
        .get<any>(
          this.baseUrl + '/get_fishbone_by_order_item_id/'+ risk_assesment + '?_format=json',{withCredentials: true}
        )
        .pipe(retry(1), catchError(this.errorHandl));
    }
}