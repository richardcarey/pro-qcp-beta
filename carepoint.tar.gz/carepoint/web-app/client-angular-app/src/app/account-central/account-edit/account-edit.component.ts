import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { NotificationService } from 'src/app/services/notification.service';
import { FormGroup, FormControl, Validators, FormBuilder, AbstractControl } from '@angular/forms';
import {Router} from "@angular/router"
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { LoadingPopupComponent } from 'src/app/dialogs/loading-popup/loading-popup.component';
import { DataService } from 'src/app/services/data.service';


@Component({
  selector: 'app-account-edit',
  templateUrl: './account-edit.component.html',
  styleUrls: ['./account-edit.component.scss']
})
export class AccountEditComponent implements OnInit {
  accountDetailsForm;
  formFieldsValidation: Array<any> = [];
  formFieldsInvalid: boolean;
  accountDetails:Array<any> = [];
  countriesList: Array<any>;
  statesList: Array<any>;
  submitted = false;
  cloneFormFields = [
    'address_line_1',
    'address_line_2',
    'locality',
    'administrative_area',
    'postal_code'
  ];
  constructor(
    private apiService: ApiService,
    private notifyService : NotificationService,
    private router: Router,
    private popupDialog: MatDialog,
    private dialogRef: MatDialogRef<LoadingPopupComponent>,
    private _DataService: DataService
    ) {
    }

  ngOnInit(): void {
    this.apiService.getAccountDetails().subscribe((data) => {
      this.accountDetails =  data[0] ;

     switch (this._DataService.currentUserRole) {
       case 'administrator':
        this.accountDetailsForm = this.createAdministratorForm();
        break;
       case 'customer':
        this.accountDetailsForm = this.createAdministratorForm();
        break;
      case 'lab_tech':
        this.accountDetailsForm = this.createBasicForm();
        break;
      case 'lab_director':
        this.accountDetailsForm = this.createBasicForm();
        break;
      case 'regulatory_affairs_manager':
        this.accountDetailsForm = this.createBasicForm();
        break;
     }
     this.onChanges();
    });

    this.apiService.getCountriesList().subscribe((data) => {
      this.countriesList =  data;
    });

    this.getStatesList('US');
  }

  createAdministratorForm() {
    return new FormGroup({
      name: new FormControl(this.accountDetails['name']),
      facility_name: new FormControl(
        this.accountDetails['facility_name'],
        [Validators.required]
      ),
      department: new FormControl(
        this.accountDetails['department'],
        [Validators.required]
      ),
      contact_name: new FormControl(
        this.accountDetails['contact_name'],
        [Validators.required]
      ),
      title: new FormControl(
        this.accountDetails['title'],
        [Validators.required]
      ),
      primary_phone: new FormControl(this.accountDetails['primary_phone'],
      [Validators.required, Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      extension: new FormControl(
        this.accountDetails['extension'],
        [Validators.pattern('[- +()0-9]+')]
      ),
      cell_phone: new FormControl(
        this.accountDetails['cell_phone'],
        [Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      fax: new FormControl(
        this.accountDetails['fax'],
        [Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      inst_phone: new FormControl(
        this.accountDetails['inst_phone'],
        [Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      billing_contact_name: new FormControl(
        this.accountDetails['billing_contact_name']
      ),
      primary_phone_billing: new FormControl(
        this.accountDetails['primary_phone_billing'],
        [ Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      billing_email: new FormControl(
        this.accountDetails['billing_email'],
        [Validators.email]
      ),
      email_billing: new FormControl(
        this.accountDetails['email_billing'],
        [Validators.email]
      ),
      mailing_address_details_address_line_1: new FormControl(
        this.accountDetails['mailing_address_details_address_line_1'],
        [Validators.required]
      ),
      mailing_address_details_address_line_2: new FormControl(
        this.accountDetails['mailing_address_details_address_line_2']
      ),
      mailing_address_details_locality: new FormControl(
        this.accountDetails['mailing_address_details_locality'],
        [Validators.required]),
      mailing_address_details_administrative_area: new FormControl(
        this.accountDetails['mailing_address_details_administrative_area'],
        [Validators.required]),
      mailing_address_details_postal_code: new FormControl(
        this.accountDetails['mailing_address_details_postal_code'],
        [Validators.required]
      ),
      mailing_address_details_country_code: new FormControl(
        'US',
        [Validators.required]
      ),
      clia: new FormControl(
        this.accountDetails['clia'], 
        [Validators.required, ValidateCLIA]
      ),
      billing_address_details_address_line_1: new FormControl(
        this.accountDetails['billing_address_details_address_line_1'],
        [Validators.required]
      ),
      billing_address_details_address_line_2: new FormControl(
        this.accountDetails['billing_address_details_address_line_2']
      ),
      billing_address_details_locality: new FormControl(
        this.accountDetails['billing_address_details_locality'],
        [Validators.required]
      ),
      billing_address_details_administrative_area: new FormControl(
        this.accountDetails['billing_address_details_administrative_area'],
        [Validators.required]
      ),
      billing_address_details_postal_code: new FormControl(
        this.accountDetails['billing_address_details_postal_code'],
        [Validators.required]
      ),
      billing_address_details_country_code: new FormControl(
        'US',
        [Validators.required]
      ),
      terms_of_use: new FormControl(
        this.accountDetails['terms_of_use'] === "1" ? true : false ,
        [Validators.requiredTrue]
      ),
      same_as_above: new FormControl(
        this.accountDetails['field_same_as_above'] === "On" ? true : false ,
      ),
    })
  }

  createBasicForm() {
    return new FormGroup({
      name: new FormControl(
        this.accountDetails['name']
      ),
      contact_name: new FormControl(
        this.accountDetails['contact_name'],
        [Validators.required]
      ),
      title: new FormControl(
        this.accountDetails['title'],
        [Validators.required]
      ),
      primary_phone: new FormControl(
        this.accountDetails['primary_phone'],
        [Validators.required, Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      cell_phone: new FormControl(
        this.accountDetails['cell_phone'],
        [Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      extension: new FormControl(
        this.accountDetails['extension'],
        [Validators.pattern('[- +()0-9]+')]
      ),
      fax: new FormControl(
        this.accountDetails['fax'],
        [Validators.pattern('[- +()0-9]+'), Validators.minLength(9)]
      ),
      terms_of_use: new FormControl(
        this.accountDetails['terms_of_use'] === "1" ? true : false ,
        [Validators.requiredTrue]
      ),
    })
  }

  onSubmit(submitedValue){
    this.submitted = true;
    if(this.accountDetailsForm.valid){
      this.postData(submitedValue);
    } else {
      // console.log('form validation failed')
      // console.log(submitedValue)
    }
  }

  getStatesList(country_code){
    this.apiService.getStatesList(country_code).subscribe((data) => {
      this.statesList =  data;
    });
  }

  get f() { return this.accountDetailsForm.controls; }


  applyFieldValues(field, value){
    return this.accountDetailsForm.controls[field].value = value ;
  }

  validateRequiredField(field, type){
    this.formFieldsValidation[field] = type;
    
  }

  checkForInvalidFields() {
    const controls = this.accountDetailsForm.controls;
    for (let field in this.formFieldsValidation ){
      if(this.formFieldsValidation[field] == "text"){
          if( controls[field].value.trim() == "" || controls[field].value == null || typeof controls[field].value == "undefined"){
            return false;
          }
      } else if (this.formFieldsValidation[field]  == "email"){
          if( !this.validateEmail(controls[field].value)) {
            return false;
          }
      } 
    }
    return true;
  }

  postData(formValues){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    this.apiService
    .updateAccountDetails(formValues)
    .subscribe((data) => {
    this._DataService.currentUserData.termsAccepted = 1;
     this.showToaster('Account Details updated!', 'Account Details')
     setTimeout(() => {
      this.dialogRef.close("");
      this.router.navigate(['/account-central'])
     }, 600);
    });
  }
  showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }
  validateEmail(email) {
      var re = /\S+@\S+\.\S+/;
      return re.test(email);
  }

  prepopulateAddressDetails(e) {
    if (e.checked) {
      for (let field_name of this.cloneFormFields) {
        let clone_field_name = this.accountDetailsForm.get('billing_address_details_' + field_name).value;
        this.accountDetailsForm.controls['mailing_address_details_' + field_name].patchValue(clone_field_name, {emitEvent:false});
      }
    }
    else {
      for (let field_name of this.cloneFormFields) {
        this.accountDetailsForm.controls['mailing_address_details_' + field_name].patchValue("", {emitEvent:false});
      }
    }
  }
  onChanges(): void {
    for (let field_name of this.cloneFormFields) {
      this.accountDetailsForm.get('mailing_address_details_' + field_name).valueChanges.subscribe(val => {
        this.accountDetailsForm.controls['same_as_above'].setValue(false);
      });
    }
  }
}

function ValidateCLIA(control: AbstractControl): {[key: string]: any} | null  {
  let cliaValidationFails = 0;
  if (control.value && control.value.length != 10) {
    cliaValidationFails++
  } 
  if (control.value && control.value.charAt(2) != "D") {
    cliaValidationFails++
  } 
  const regex = /^[0-9]+$/;
  if (control.value && !control.value.substring(0, 2).match(regex)) {
    cliaValidationFails++
  }
  if (control.value && !control.value.substring(3, 10).match(regex)) {
    cliaValidationFails++
  } 

  return cliaValidationFails > 0 ? { 'cliaInvalid': true } : null;
}
