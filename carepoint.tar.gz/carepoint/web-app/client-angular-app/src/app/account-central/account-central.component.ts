import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';
import { LocationsDialogComponent } from './locations-dialog/locations-dialog.component';
import { ModulesDialogComponent } from './modules-dialog/modules-dialog.component';
import { UsersDialogComponent } from './users-dialog/users-dialog.component';
import { NotificationService } from 'src/app/services/notification.service';
import { InfoComponent } from '../dialogs/info/info.component';


export interface PeriodicElement {
  assessment_id: number;
  identifier: string;
  department: string;
  manufacturer: string;
  device: string;
  part: string;
  version: string;
  expiration_date: string;
}
@Component({
  selector: 'app-account-central',
  templateUrl: './account-central.component.html',
  styleUrls: ['./account-central.component.scss']
})
export class AccountCentralComponent implements OnInit {
  ModulesColumns: string[] = ['assessment_id', 'identifier', 'department', 'manufacturer', 'device', 'part', 'version', 'expiration_date', 'status'];
  LocationsColumns: string[] = ['location_id', 'location', 'department', 'clia'];
  UsersColumns: string[] = ['user_id', 'name', 'title', 'role', 'email', 'location'];
  currentUserRole: string
  userModules: any = [];
  iqcpLocations: any = [];
  users: any = [];
  accountDetails:Array<any> = [];
  panelOpenState = false;
  lab_tech: boolean = false;
  carepoint_customer: boolean = false;
  canSeeLocations = ["administrator", "customer"];
  canSeeModules = ["administrator", "lab_director", "regulatory_affairs_manager", "customer", "lab_tech"];
  canEditModules = ["administrator", "customer"];
  canSeeUsers = ["administrator", "lab_director", "customer"];
  canSeeFacility = ["administrator", "customer"];
  canSeeAddressDetails = ["administrator", "customer"];
  constructor(
    private apiService: ApiService, 
    private authService: AuthService, 
    public dialog: MatDialog, 
    private _DataService: DataService,
    public notifyService: NotificationService,
    private infoDialog: MatDialog,
    ) {
  
   }

  ngOnInit(): void {
    this.currentUserRole = this._DataService.currentUserRole;
    
    this.authService.getUserData().subscribe((data) => {
      
      this.apiService.getModulesList().subscribe((data) => {
        this.userModules = data
      });
  
      this.apiService.getAccountDetails().subscribe((data) => {
        this.accountDetails =  data[0] ;
      });

     this.getLocationsByRole(this.currentUserRole);
      
     this.getUsersByRole(this.currentUserRole);

     this.showNotification();
      
    });
    
  }

  showNotification(){
    let deviceWidth = window.screen.width;
    if(deviceWidth < 1024){
      this.notifyService.showWarning('CarePoint is not optimized for smaller devices, we recommend using larger screen devices.', '');
    }
    
  }
  
  getLocationsByRole(role) {
    switch (role) {
      case "administrator":
        this.apiService.getIqcpLocation().subscribe((data) => {
          this.iqcpLocations =  data ;
         
        });
        break;
      case "customer":
        this.apiService.getIqcpLocation().subscribe((data) => {
          this.iqcpLocations =  data ;
        });
        break;
      case "lab_director":
        this.apiService.getAssociatedLocations().subscribe((data) => {
          this.iqcpLocations =  data ;
        });
        break;
    }
  }

  getUsersByRole(role){
     switch (role) {
       case "administrator":
          this.apiService.getUsersByOrganization().subscribe((data) => {
            this.users =  data ;
          });
         break;
       case "customer":
          this.apiService.getUsersByOrganization().subscribe((data) => {
            this.users =  data ;
          });
         break;
       case "lab_director":
          this.apiService.getUsersByLocation().subscribe((data) => {
            this.users =  data ;
          });
         break;
     }

  }

  openLocationsDialog(location = null) {
    const locationsDialog = this.dialog.open(LocationsDialogComponent,{
      height: '450px',
      width: '600px',
      data: location,
      panelClass: 'locations-dialog'
    });

    locationsDialog.afterClosed().subscribe(result => {
      this.apiService.getIqcpLocation().subscribe((data) => {
        this.iqcpLocations =  data ;
      });
    });
  }

  openUsersDialog(user = null) {
    let data = []
    data['locations'] = this.iqcpLocations
    data['user'] = user
    const usersDialog = this.dialog.open(UsersDialogComponent,{
      height: '570px',
      width: '600px',
      data: data,
      panelClass: 'locations-dialog'
    });

    usersDialog.afterClosed().subscribe(result => {
      this.getUsersByRole(this.currentUserRole);
    });
  }

  openModulesDialog(order) {
    let data = []
    data['locations'] = this.iqcpLocations
    data['order'] = order
    const modulesDialog = this.dialog.open(ModulesDialogComponent,{
      height: '370px',
      width: '600px',
      data: data,
      panelClass: 'locations-dialog'
    });

    modulesDialog.afterClosed().subscribe(result => {
      this.apiService.getModulesList().subscribe((data) => {
        this.userModules = data
      });
    });
  }

  isUserRole(roles, role){
    for(let [key, val] of Object.entries(roles)){
      if(role == val){
        return true;
      }
    }
    return false;
  }

  getRoleNameByKey(role){
    switch (role) {
      case "lab_tech":
        return "User";
        break;
      case "regulatory_affairs_manager":
        return "View Only";
        break;
      case "lab_director":
        return "Administrator";
        break;
      case "customer":
        return "Administrator";
        break;

    }
  }

  showSectionInfo(key) {
    let infoTitle, infoText;
    switch (key) {
      case "open-module":
        infoTitle = "Open Module";
        infoText = "Please assign the Pro-QCP module to a specific location";
        break;
      case "iqcp-actions":
        infoTitle = "IQCP Locations";
        infoText = "Ability to edit, location IQCP name and CLIA number.";
        break;
      case "iqcp-add":
        infoTitle = "Add Location Info";
        infoText = "User can add a new location (please add location assigned to your network)";
        break;
      case "module-actions":
        infoTitle = "Open or Edit Pro-QCP specific module";
        infoText = "OPEN - In order to proceed with risk assessment <br> EDIT - Assign your Pro-QCP module to a specific location";
        break;
      case "module-expiration":
        infoTitle = "Expiration Date Info";
        infoText = "Expiration date for Pro-QCP module subscription";
        break;
      case "module-status":
        infoTitle = "Status Info";
        infoText = "Indicator if the module is active or expired";
        break;
      case "user-add":
        infoTitle = "Add User Info";
        infoText = "Add and assign a new user to your organization or location.";
        break;
      case "user-edit":
        infoTitle = "Edit User Info";
        infoText = "Ability to edit account details of a user that belongs to your organization.";
        break;
    }
    this.infoDialog.open(InfoComponent, {
      width: '40%',
      data: {
        title: infoTitle,
        paragraphOne: infoText,
        paragraphTwo: ''
      }
    });
  }

}
