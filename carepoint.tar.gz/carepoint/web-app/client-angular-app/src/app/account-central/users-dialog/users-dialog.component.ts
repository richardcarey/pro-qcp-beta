import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import { NotificationService } from 'src/app/services/notification.service';
import { LoadingPopupComponent } from 'src/app/dialogs/loading-popup/loading-popup.component';
import { DataService } from 'src/app/services/data.service';
import { InfoComponent } from 'src/app/dialogs/info/info.component';
@Component({
  selector: 'app-users-dialog',
  templateUrl: './users-dialog.component.html',
  styleUrls: ['./users-dialog.component.scss']
})
export class UsersDialogComponent implements OnInit {
  usersForm;
  iqcpLocations: Array<any> ;
  email = new FormControl('', [Validators.required, Validators.email]);
  formFieldsValidation: Array<any> = [];
  locationID: number;
  showLocations: boolean = false;
  multipleLocations: boolean = false;
  submitted = false;
  emailIsUsed = false;
  usernameIsUsed = false;
  selectedUser: any = false;
  isEditForm = false;
  formSubmited = false;
  userTypes: any;
  selectedRoleInfo: Array<any> = [];
  carepointAdminUserTypes = [
    { 
      key:"lab_tech",
      value: "User",
      info: "View, edit and print assessments and reports"
    },
    {
      key: "regulatory_affairs_manager",
      value: "View Only",
      info: "View and print reports"
    },{
      key: "lab_director",
      value: "Administrator",
      info: "View, edit and print assessments and reports, Add and manage users"
    }
  ];
  labDirectorUserTypes = [
    { 
      key:"lab_tech",
      value: "User"
    }
  ];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, 
    private apiService: ApiService, 
    private notifyService : NotificationService, 
    private popupDialog: MatDialog, 
    public dialogRef: MatDialogRef<LoadingPopupComponent>,
    private _DataService: DataService,
    private infoDialog: MatDialog,
    ) {
    this.usersForm = this.createFormGroup();
  }

  ngOnInit(): void {
    const currentUserRole = this._DataService.currentUserRole;
    this.userTypes = currentUserRole === "administrator" ||  currentUserRole === "customer" ? this.carepointAdminUserTypes : this.labDirectorUserTypes;
    this.iqcpLocations =  this.data['locations'];
    this.selectedUser = this.data['user'];
    this.setUserRoleInfo(currentUserRole);
    if(this.selectedUser){
      this.populateUserForm(this.selectedUser);
      this.isEditForm = true;
    }
  
  }

  populateUserForm(user) {
    if(user.role === "lab_director"){
      setTimeout(() => {
        this.multipleLocations = true;
        this.usersForm = this.createFormGroup(this.selectedUser.name, this.selectedUser.title, this.selectedUser.role, this.selectedUser.email, this.selectedUser.location_ids);
      }, 100);
    }
    if(user.role === "lab_tech"){
      setTimeout(() => {
        this.multipleLocations = false;
        this.usersForm = this.createFormGroup(this.selectedUser.name, this.selectedUser.title, this.selectedUser.role, this.selectedUser.email, this.selectedUser.location_ids);
      }, 100);
    }
    if(user.role === "regulatory_affairs_manager"){
      setTimeout(() => {
        this.multipleLocations = false;
        this.showLocations = false;
        this.usersForm.pristine = false
        this.usersForm = this.createFormGroup(this.selectedUser.name, this.selectedUser.title, this.selectedUser.role, this.selectedUser.email, this.selectedUser.location_ids);
      }, 100);
    }
  }

  checkIsEmailUsed(email){
    this.apiService.checkIsEmailUsed(email).subscribe((data) => {
      this.emailIsUsed =  typeof data[0] !== "undefined" ? true : false;
    });
  }

  createFormGroup(name = '', title = '', role ='lab_tech', email ='', location : Array<any> = [], locationRequired = true) {
    this.showLocations = true;
    let location_value = !this.multipleLocations && location.length > 0 ? location[0] : location;
    return new FormGroup({
      name: new FormControl(name,[
        Validators.required]),
      title: new FormControl(title,[
        Validators.required]),
      role: new FormControl(role,[
        Validators.required]),
      email: new FormControl(email,[
        Validators.email, Validators.required]),
      location: new FormControl(location_value , locationRequired ? [Validators.required] : []),
    })
  }

  onSubmit(submitedValue){
    this.submitted = true;
    if(this.checkForInvalidFields() && this.usersForm.valid && !this.isEditForm && !this.formSubmited){
      this.formSubmited = true;
      this.apiService.checkIsEmailUsed(submitedValue.email).subscribe((emailResponse) => {
        this.emailIsUsed =  typeof emailResponse[0] !== "undefined" ? true : false;
        this.apiService.checkIsUsernameValid(submitedValue.name).subscribe((nameResponse) => {
          this.usernameIsUsed =  typeof nameResponse[0] !== "undefined" ? true : false;
          if(!this.emailIsUsed && !this.usernameIsUsed){
              this.formSubmited = true;
            
              this.postData(submitedValue);
              this.emailIsUsed = false;
              this.usernameIsUsed = false;
          } else {
            this.formSubmited = false;
          }
        });
      });
     
    } else if(this.isEditForm && this.checkForInvalidFields() && !this.formSubmited){
      this.formSubmited = true;
      this.updateData(submitedValue);
      this.emailIsUsed = false;
      this.usernameIsUsed = false;
    } else {
      console.log('form validation failed')
    }
  }

  onRoleSelected(role){
    switch (role.value) {
      case "regulatory_affairs_manager":
        this.usersForm = this.createFormGroup(this.usersForm.value.name, this.usersForm.value.title, role.value, this.usersForm.value.email, [], false);
        this.showLocations = false;
        this.usersForm.pristine = false
        this.multipleLocations = false;
        break;
      case "lab_director":
        this.usersForm = this.createFormGroup(this.usersForm.value.name, this.usersForm.value.title, role.value, this.usersForm.value.email, []);
        this.showLocations = true;
        this.multipleLocations = true;
        break;
      case "lab_tech":
        this.usersForm = this.createFormGroup(this.usersForm.value.name, this.usersForm.value.title, role.value, this.usersForm.value.email, []);
        this.showLocations = true;
        this.multipleLocations = false;
        break;
    }
  }


  validateRequiredField(field, type){
    this.formFieldsValidation[field] = type;
  }

  removeUser(){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    this.selectedUser.location = this.locationID;
    this.apiService.removeUser(this.selectedUser).subscribe((data) => {
     this.showToaster('User Removed!', 'Users')
     setTimeout(() => {
      document.getElementById("usersModalClose").click();
      this.dialogRef.close("");
    }, 500);
    });
  }
  postData(formValues){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    if(this.showLocations){
      this.apiService.addUserToLocation(formValues).subscribe((data) => {
        this.showToaster('User Added!', 'Users')
        setTimeout(() => {
         document.getElementById("usersModalClose").click();
         this.dialogRef.close("");
       }, 500);
       });
    } else {
      this.apiService.addNewUser(formValues).subscribe((data) => {
        this.showToaster('User Added!', 'Users')
        setTimeout(() => {
         document.getElementById("usersModalClose").click();
         this.dialogRef.close("");
       }, 500);
       });
    }

  }

  updateData(formValues){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    formValues.user_id = this.selectedUser.user_id
    this.apiService.updateUserDataOrLocation(formValues).subscribe((data) => {
     this.showToaster('User Uploaded!', 'Users')
     setTimeout(() => {
      document.getElementById("usersModalClose").click();
      this.dialogRef.close("");
    }, 500);
    });
  }

  showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }

  get f() { return this.usersForm.controls; }
  // get emailUsed() { return this.emailIsUsed}

  checkForInvalidFields() {
    const controls = this.usersForm.controls;
    for (let field in this.formFieldsValidation ){
      if(this.formFieldsValidation[field] == "text"){
          if( controls[field].value.trim() == "" || controls[field].value == null || typeof controls[field].value == "undefined"){
            if(this.showLocations && field === "location"){
              return true;
            }
            return false;
          }
      } else if (this.formFieldsValidation[field]  == "email"){
          if( !this.validateEmail(controls[field].value)) {
            return false;
          }
      }
    }
    return true;
  }

  validateEmail(email) {
      var re = /\S+@\S+\.\S+/;
      return re.test(email);
  }

  showRoleInfo() {
    this.infoDialog.open(InfoComponent, {
      width: '40%',
      data: {
        title: this.selectedRoleInfo["title"],
        paragraphOne: this.selectedRoleInfo["info"],
        paragraphTwo: ''
      }
    });
  }

  setUserRoleInfo(role){

    switch (role) {
      case "administrator":
        this.selectedRoleInfo["title"] = "Roles and Permissions";
        this.selectedRoleInfo["info"] = "<table class='info-dialog-table' >";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<th>Role</th>";
        this.selectedRoleInfo["info"] += "<th>Permissions</th>";
        this.selectedRoleInfo["info"] += "</tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='2' class='info-dialog-role-info-data left-role-info-col'>Administrator</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View, edit and print assessments and reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += " <td class='info-dialog-role-info-data'>Add and manage users</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='1' class='info-dialog-role-info-data left-role-info-col'>User</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View, edit and print assessments and reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='1' class='info-dialog-role-info-data left-role-info-col'>View Only</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View and print reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "</table>";
        break;
      case "customer":
        this.selectedRoleInfo["title"] = "Roles and Permissions";
        this.selectedRoleInfo["info"] = "<table class='info-dialog-table' >";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<th>Role</th>";
        this.selectedRoleInfo["info"] += "<th>Permissions</th>";
        this.selectedRoleInfo["info"] += "</tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='2' class='info-dialog-role-info-data left-role-info-col'>Administrator</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View, edit and print assessments and reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += " <td class='info-dialog-role-info-data'>Add and manage users</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='1' class='info-dialog-role-info-data left-role-info-col'>User</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View, edit and print assessments and reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='1' class='info-dialog-role-info-data left-role-info-col'>View Only</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View and print reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "</table>";
        break;
      case "lab_director":
        this.selectedRoleInfo["title"] = "Roles and Permissions";
        this.selectedRoleInfo["info"] = "<table class='info-dialog-table' >";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<th>Role</th>";
        this.selectedRoleInfo["info"] += "<th>Permissions</th>";
        this.selectedRoleInfo["info"] += "</tr>";
        this.selectedRoleInfo["info"] += "<tr>";
        this.selectedRoleInfo["info"] += "<td rowspan='1' class='info-dialog-role-info-data left-role-info-col'>User</td>";
        this.selectedRoleInfo["info"] += "<td class='info-dialog-role-info-data'>View, edit and print assessments and reports</td>";
        this.selectedRoleInfo["info"] += " </tr>";
        this.selectedRoleInfo["info"] += "</table>";
        break;
  
    }
  }
}









