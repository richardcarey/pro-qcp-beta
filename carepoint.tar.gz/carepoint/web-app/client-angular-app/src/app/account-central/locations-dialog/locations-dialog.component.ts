import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {AbstractControl, FormControl, FormGroup, Validators} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import { NotificationService } from 'src/app/services/notification.service';
import { LoadingPopupComponent } from 'src/app/dialogs/loading-popup/loading-popup.component';
@Component({
  selector: 'app-locations-dialog',
  templateUrl: './locations-dialog.component.html',
  styleUrls: ['./locations-dialog.component.scss']
})
export class LocationsDialogComponent implements OnInit {
  locationsForm;
  email = new FormControl('', [Validators.required, Validators.email]);
  formFieldsValidation: Array<any> = [];
  submitted = false;
  deleteBtn = false;
  deleteError = false;
  formSubmited = false;
  deleteMessage = "";
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private popupDialog: MatDialog, public dialogRef: MatDialogRef<LoadingPopupComponent>, private apiService: ApiService, private notifyService : NotificationService) {
    this.locationsForm = this.createFormGroup();
  }

  ngOnInit(): void {
    if(this.data){
      this.deleteBtn = true;
      this.locationsForm = this.createFormGroup(this.data.location, this.data.department, this.data.clia);
    }
  }



  createFormGroup(location = '', department = '', clia = '' ) {
    return new FormGroup({
      location: new FormControl(location,[
        Validators.required]),
      department: new FormControl(department,[
        Validators.required]),
      clia: new FormControl(clia, [Validators.required, ValidateCLIA]),
    })
  }

  onSubmit(submitedValue){
    this.submitted = true;
    if(this.locationsForm.valid && !this.formSubmited){
      this.formSubmited = true;
      if(this.data){
        this.updateData(submitedValue);
      }else {
        this.postData(submitedValue);
      }
    } else {
      // console.log('form validation failed')
    }
  }

  postData(formValues){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    this.apiService.addIqcpLocation(formValues).subscribe((data) => {
     this.showToaster('Location Added!', 'IQCP Locations')
     setTimeout(() => {
      document.getElementById("locationsModalClose").click();
      this.dialogRef.close("");
    }, 500);
    });
  }
  updateData(formValues){
    this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
      data: {
        message: 'Your request is being processed...'
      },
      width: '300px',
    });
    formValues.location_id = this.data.location_id;
    this.apiService.updateIqcpLocation(formValues).subscribe((data) => {
      this.showToaster('Location Updated!', 'IQCP Locations')
      setTimeout(() => {
       document.getElementById("locationsModalClose").click();
       this.dialogRef.close("");
     }, 500);
     });
  }
  showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }
  deleteLocation(data){
    
    this.apiService.deleteIqcpLocation(data).subscribe((data) => {
      if(data.response === 0){
        this.deleteError = true;
        this.deleteMessage = "This Location has Order Associated and can not be deleted!"
      } else if(data.response === 1){
        this.deleteError = true;
        this.deleteMessage = "This Location has Users Associated and can not be deleted!"
      } else if(data.response === 2){
        this.showToaster('Location Deleted!', 'IQCP Locations')
        setTimeout(() => {
         document.getElementById("locationsModalClose").click();
        }, 500);
      }
      
     });
  }

  get f() { return this.locationsForm.controls; }
}

function ValidateCLIA(control: AbstractControl): {[key: string]: any} | null  {
  let cliaValidationFails = 0;
  if (control.value && control.value.length != 10) {
    cliaValidationFails++
  } 
  if (control.value && control.value.charAt(2) != "D") {
    cliaValidationFails++
  } 
  const regex = /^[0-9]+$/;
  if (control.value && !control.value.substring(0, 2).match(regex)) {
    cliaValidationFails++
  }
  if (control.value && !control.value.substring(3, 10).match(regex)) {
    cliaValidationFails++
  } 

  return cliaValidationFails > 0 ? { 'cliaInvalid': true } : null;
}


