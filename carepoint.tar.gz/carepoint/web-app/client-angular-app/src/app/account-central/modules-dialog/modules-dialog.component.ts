import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import { NotificationService } from 'src/app/services/notification.service';
import { LoadingPopupComponent } from 'src/app/dialogs/loading-popup/loading-popup.component';

@Component({
  selector: 'app-modules-dialog',
  templateUrl: './modules-dialog.component.html',
  styleUrls: ['./modules-dialog.component.scss']
})
export class ModulesDialogComponent implements OnInit {
  modulesForm;
  iqcpLocations: any;
  selectedOrder: any;
  locationID: string;
  isEditForm = false;
  formSubmited = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private popupDialog: MatDialog, public dialogRef: MatDialogRef<LoadingPopupComponent>, private apiService: ApiService, private notifyService : NotificationService) {
    this.modulesForm = this.createFormGroup();
   }

  ngOnInit(): void {
    this.iqcpLocations = this.data['locations'];
    this.selectedOrder = this.data['order'];
    
    if(this.selectedOrder){
      this.isEditForm = true;
      let location_id = "";
      if(typeof  this.selectedOrder.location_id !== "undefined"){
        location_id = this.selectedOrder.location_id;
      }
      this.modulesForm = this.createFormGroup( this.selectedOrder.identifier, location_id );
    }
  }

  createFormGroup(module = '', department = '') {
    return new FormGroup({
      module: new FormControl(module,[
        Validators.required]),
      location_id: new FormControl(department,[
        Validators.required]),
    })
  }

  onSubmit(submitedValue){
    submitedValue.order_id = this.selectedOrder.order_id
    submitedValue.order_item_id = this.selectedOrder.order_item_id
    if(  !this.formSubmited ){
      this.formSubmited = true;
      this.apiService.setOrderLocation(submitedValue).subscribe((response) => {
        this.dialogRef = this.popupDialog.open(LoadingPopupComponent, {
          data: {
            message: 'Your request is being processed...'
          },
          width: '300px',
        });
        this.showToaster('Module Updated!', 'Modules')
        setTimeout(() => {
          document.getElementById("modulesModalClose").click();
          this.dialogRef.close("");
        }, 500);
      });
    }
  }

  showToaster(message, title) {
    this.notifyService.showSuccess(message, title);
  }

}
