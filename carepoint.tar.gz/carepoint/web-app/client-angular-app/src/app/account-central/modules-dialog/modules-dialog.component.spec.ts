import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModulesDialogComponent } from './modules-dialog.component';

describe('ModulesDialogComponent', () => {
  let component: ModulesDialogComponent;
  let fixture: ComponentFixture<ModulesDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModulesDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModulesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
