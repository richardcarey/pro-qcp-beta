
import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'carepoint-app';
  isLoading = true;
  routerMessage: any;

  constructor(
    private _DataService: DataService,
    ) {}

  ngOnInit() {
    this._DataService.currentMessage.subscribe(message => 
      this.updateMessage(500, message)
      );
   }

  updateMessage(timeout, message){
    this.isLoading = true;
    setTimeout(() => {
      this.isLoading = false;
      this.routerMessage = message
    }, timeout);
  }
}
