export enum Role {
    Admin = "administrator",
    Customer = "customer",
    Basic = "lab_tech",
    RegulatoryAffairsManager = "regulatory_affairs_manager",
    LabDirector = "lab_director",

}