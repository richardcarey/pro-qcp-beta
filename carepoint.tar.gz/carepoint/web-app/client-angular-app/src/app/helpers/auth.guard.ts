import { PlatformLocation } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable} from 'rxjs';
import { map } from "rxjs/operators";
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    currentUserRole: string;
    baseUrl;
    message: any;
    constructor(
        private router: Router,
        private _DataService: DataService,
        private authService: AuthService,
        private platformLocation: PlatformLocation
    ) { 
        let hash = (platformLocation as any).location.hash;
        let searchIndex = hash.indexOf("#/") +1 ;
        this.baseUrl = hash.substring(0, searchIndex);
    }
    
    canActivate(route: ActivatedRouteSnapshot): Observable<any> {
        return this.authService.getUserData().pipe(map((response: any) => 
            this.checkCanUserAccess(route, response)
        ));
    }

    checkCanUserAccess(route, data){
        if(typeof data !== "undefined"){
            this.currentUserRole = typeof data.roles[1] !== "undefined" ? data.roles[1] : null;
            const termsAccepted = parseInt(data.termsAccepted);
            if(this.currentUserRole){
                let routePath = route['_routerState'].url;
                if (route.data.roles && route.data.roles.indexOf(this.currentUserRole) === -1) {
                    //user not authorized to access this page
                    this._DataService.setRouterMessage("You are not authorized to access this page. <a class='edit-account' href='"+this.baseUrl+"/account-central' >Go back!</a>.");
                    return true;
                } else if(!termsAccepted && routePath !== '/account-central/edit-account'){
                    this._DataService.setRouterMessage("You need to accept <a href='"+this.baseUrl+"/account-central/edit-account'>Terms of Service</a> in order to continue using CarePoint account.");
                    return true;
                }
                this._DataService.setRouterMessage('');
                return true
            }
        }
        this._DataService.setRouterMessage("You have to be logged in to access this page, please <a href='/user/login'>login with your CarePoint account</a>.");
        return true
    }

}