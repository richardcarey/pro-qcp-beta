#!/bin/bash

/wait

touch ./sites/default/settings.php

vendor/bin/drupal site:install standard \
  --langcode=en \
  --db-type=mysql \
  --db-host=${CP_DATABASE_HOST} \
  --db-name=${CP_DATABASE_NAME} \
  --db-user=${CP_DATABASE_USER} \
  --db-pass=${CP_DATABASE_PASSWORD} \
  --db-port=${CP_DATABASE_PORT} \
  --site-name=${SITE_NAME:-Carepoint} \
  --site-mail=${SITE_MAIL:-admin@mail.com} \
  --account-name=${ACCOUNT_NAME:-admin} \
  --account-mail=${ACCOUNT_MAIL:-admin@mail.com} \
  --account-pass=${ACCOUNT_PASS:-password} \
  --no-interaction

vendor/bin/drupal config:import --directory=/drupal-configuration

printf '\n%s\n' "\$settings['reverse_proxy'] = TRUE;" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$settings['reverse_proxy_addresses'] = [\$_SERVER['REMOTE_ADDR']];" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$settings['reverse_proxy_trusted_headers'] = \Symfony\Component\HttpFoundation\Request::HEADER_X_FORWARDED_ALL | \Symfony\Component\HttpFoundation\Request::HEADER_FORWARDED;" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$settings['trusted_host_patterns'] = ['${CP_TRUSTED_HOST}'];" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$settings['file_private_path'] = '/var/www/html/private';" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$config['commerce_payment.commerce_payment_gateway.ez_qcp_payment_gateway']['configuration']['publishable_key'] = '${CP_PK}';" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$config['commerce_payment.commerce_payment_gateway.ez_qcp_payment_gateway']['configuration']['secret_key'] = '${CP_SK}';" >> /var/www/html/sites/default/settings.php
printf '\n%s\n' "\$config['commerce_payment.commerce_payment_gateway.ez_qcp_payment_gateway']['configuration']['mode'] = '${CP_MODE}';" >> /var/www/html/sites/default/settings.php



# Rebuild caches.
vendor/bin/drupal cr

# Start Apache
apache2-foreground
