<?php

class Module {

    public $sort;
    public $module_name;
    public $part_number;
    public $price;
    public $analytes;
    public $category;

    public function __construct(array $module)
    {
        $this->sort = $module[0];
        $this->module_name = $module[1];
        $this->part_number = $module[2];
        $this->price = $module[3];
        $this->analytes = $module[4];
        $this->category = $module[5];
    }
}

class Assessment {
    public $assessment_id;
    public $is_demo;
    public $fishbone;
    public $Manufacturer__c;
    public $test_system;
    public $Cartridge;
    public $matrix_id;
    public $analytes;
    public $assessment_name;
    public $Part_Number;
    public $Price;
    public $Product_group;
    public $Status;
    public $Title;
    public $Display_Sort__c;
    public $string_token_replacement_values = array();
    public $acceptabilty_matrix = array();
    public $wards = array();
    public $accrediting_agency = array();
    public $risks = array();


    public function __construct($assesment)
    {
        $this->assessment = $assesment;
        $this->assessment_id = $assesment[0];
        $this->is_demo = $assesment[1];
        $this->fishbone = $assesment[2];
        $this->Manufacturer__c = $assesment[3];
        $this->test_system = $assesment[4];
        $this->Cartridge = $assesment[5];
        $this->is_generic = $assesment[6];
        if(isset($assesment[7])){
            $this->analytes = $assesment[7];
        }else{
            echo "DEBUG7:" . $assesment[0] . PHP_EOL;
        }
        if(isset($assesment[8])){
            $this->assessment_name = $assesment[8];
        }else{
            echo "DEBUG8:" . $assesment[0] . PHP_EOL;
        }
   
        $this->Part_Number = $assesment[9];
        $this->Price = $assesment[10];
        $this->Product_group = $assesment[11];
        $this->Status = $assesment[12];
        $this->Title = $assesment[13];
        $this->Display_Sort__c = $assesment[14];
    }

    public function setReplacements($replacement_patterns){
      $replacements = array();
      $replacements['??Device??'] = $this->assessment[4];
      $replacements['??Test??'] = $this->assessment[5];
      $replacements['??test??'] = $this->assessment[5];
      $replacements['??Analytes??'] = $this->assessment[7];
      $assessment_key = 15;
      foreach($replacement_patterns as $key => $replacement_pattern) {
        $replacements[trim($replacement_pattern[0])] = $this->assessment[$assessment_key];
        $assessment_key++;
      }
        $this->string_token_replacement_values = $replacements;

        // null values from csv
        unset($this->assessment);
    }

}

class Replacments {
    public $key;
    public $value;
}


class Risk {
    public $Add_to_Risk_Table;
    public $Cat;
    public $Index;
    public $RISK_Statement;
    public $Activity;
    public $Common_Risk;
    public $Specific_Risk;
    public $row_id;

    public function __construct($risk, $row_id)
    {
        $this->Add_to_Risk_Table = $risk[0];
        $this->Cat = $risk[1];
        $this->Index = $risk[2];
        $this->RISK_Statement = $risk[3];
        $this->Risk_abbreviated_terms = $risk[4];
        $this->Activity = $risk[5];
        $this->Common_Risk = $risk[6];
        $this->Specific_Risk = $risk[7];
        $this->row_id = $row_id;
        
    }
}

class AssessmentToRisk {
    public $assesment_id;
    public $risk_Index;
    public $enabled = false;

}


class QCP {
    public $Add_to_QCP_Table = "N";
    public $QCP_ID;
    public $Action;
    public $Frequency;
    public $Criteria;
    public $risk_Index;

    public $CAP_Citation;
    public $CAP_txt;

    public $TJC_Citation;
    public $TJC_txt;

    public $CLIA_Citation;
    public $CLIA_txt;

    public $COLA_Citation;
    public $COLA_txt;

    public function __construct($qcp)
    {
        $this->Add_to_QCP_Table = $qcp[0];
        $this->QCP_ID = $qcp[1];
        $this->Action = $qcp[2];
        $this->Frequency = $qcp[3];
        $this->Criteria = $qcp[4];

        $this->CAP_Citation = $qcp[6];
        $this->CAP_txt = $qcp[7];
    
        $this->TJC_Citation = $qcp[8];
        $this->TJC_txt = $qcp[9];
    
        $this->CLIA_Citation = $qcp[10];
        $this->CLIA_txt = $qcp[11];
    
        $this->COLA_Citation = $qcp[12];
        $this->COLA_txt = $qcp[13];
    }

}

class RiskToQCP {

    public $risk_Index;
    public $QCP_ID;
    public $enabled = false;

}


function flipDiagonally($arr) {
    $out = array();
    foreach ($arr as $key => $subarr) {
        //echo "columns$key" . count($subarr) . PHP_EOL;
        foreach ($subarr as $subkey => $subvalue) {
            $out[$subkey][$key] = $subvalue;
        }
    }
    return $out;
}


function csv_to_array($filename='', $delimiter=',')
{
	if(!file_exists($filename) || !is_readable($filename))
		return FALSE;
	
	$header = NULL;
	$data = array();
	if (($handle = fopen($filename, 'r')) !== FALSE)
	{
		while (($row = fgetcsv($handle, 10000, $delimiter)) !== FALSE)
		{
				$data[] = $row;
		}
		fclose($handle);
	}
	return $data;
}

class Comments {
  public $risk_assessment;
  public $comments;
  function __construct($risk_assessment, $comments) {
    $this->risk_assessment = $risk_assessment;
    $this->comments = $comments;
  }

  public function mapCommentsToRisks() {
    $column_array = self::createColumnsArray('FC');
    $column_array = array_splice($column_array, 9, count($column_array));
    $column_array = array_flip($column_array);

    foreach ($this->comments as $key => $comment) {
      $column_string = preg_replace("/[^A-Za-z?! ]/",'',$key);
      $column_num = preg_replace("/[^0-9?! ]/",'',$key);
      $assessment_comments = isset($this->risk_assessment[$column_array[$column_string]]) ? $this->risk_assessment[$column_array[$column_string]] : FALSE;
      if ($assessment_comments) {
        $risks = $assessment_comments->risks;
        foreach ($risks as $key => $risk) {
          $risk_row_id = $risk['row_id'] + 1;
          if ($risk_row_id == $column_num) {
            $risk['citation'] = $comment;
            $assessment_comments->risks[$key] = $risk;
          }
        }
        $this->risk_assessment[$column_array[$column_string]] = $assessment_comments;
      }   
    }
  }
  
  public static function createColumnsArray($end_column, $first_letters = '') {
    $columns = array();
    $length = strlen($end_column);
    $start_range = empty($first_letters) ? 'I' : 'A';
    $letters = range('A', 'Z');
  
    // Iterate over 26 letters.
    foreach ($letters as $letter) {
      // Paste the $first_letters before the next.
      // Remove O value from sheet columns

      $column = $first_letters . $letter;
  
      // Add the column to the final array.
      $columns[] = $column;
  
      // If it was the end column that was added, return the columns.
      if ($column == $end_column) {
        return $columns;
      }   
    }
  
    // Add the column children.
    foreach ($columns as $column) {
      // Don't itterate if the $end_column was already set in a previous itteration.
      // Stop iterating if you've reached the maximum character length.
      if (!in_array($end_column, $columns) && strlen($column) < $length) {
        $new_columns = self::createColumnsArray($end_column, $column);
        // Merge the new columns which were created with the final columns array.
        $columns = array_merge($columns, $new_columns);
      }
    }
    return $columns;
  }
}