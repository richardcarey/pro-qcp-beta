<?php
$row = 0;
if (($handle = fopen("import_test_type.csv", "r")) !== FALSE) {
  $csv_data = [];
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        echo "<p> $num fields in line $row: <br /></p>\n";
        $csv_data[] = $data;
        
    }
    fclose($handle);
    $format_array = [];
    $removed = array_shift($csv_data);
    foreach ($csv_data as $key => $value) {
      for($i = 0; $i < count($value); $i++) {
        $format_array[$key][$removed[$i]] = $value[$i]; 
      }
    }
    print_r($format_array);
    $data_test_type_json = json_encode($format_array, JSON_PRETTY_PRINT);

    file_put_contents('import_test_type.json', $data_test_type_json);
}
?>