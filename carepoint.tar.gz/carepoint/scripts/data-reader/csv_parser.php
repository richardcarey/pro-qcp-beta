//<?php

require_once 'Models.php';

$risk_master = array_map('str_getcsv', file('risk_master.csv'));


//print_r($risk_master[0]);

echo count($risk_master) . "x"  . count($risk_master[3]) . PHP_EOL;

echo count($risk_master) . "x"  . count(end($risk_master)) . PHP_EOL;



foreach ($risk_master[3] as $key => $value) {
    echo $value . "|" . $risk_master[2][$key] . PHP_EOL;
}


function excelColumnRange($lower, $upper) {
    ++$upper;
    for ($i = $lower; $i !== $upper; ++$i) {
        yield $i;
    }
}

$number_to_letter_map = [];

$number_to_letter_map[0] = 0;

foreach (excelColumnRange('A', 'PC')  as $value) {
    $number_to_letter_map[] = $value;
    //echo $value, PHP_EOL;
}

//print_r($number_to_letter_map);


$comments = json_decode(file_get_contents("all_comments.json"), true);  

$comments_indexed = [];

foreach ($comments as $key => $value) {
     $anchor = json_decode($value['anchor']);
     $comments_indexed[$anchor[4][1]] = $value['htmlContent'];
}

echo "Comments:" . count($comments_indexed) . PHP_EOL;

file_put_contents("comments_indexed.json", json_encode($comments_indexed), JSON_PRETTY_PRINT);

$risk_master_w_comments = [];

foreach ( $risk_master  as $row_num => $row ) {
    foreach ($number_to_letter_map as $column => $cell) {
        if(isset($comments_indexed[$number_to_letter_map[$column] . ($row_num + 1)])){
            $risk_master_w_comments[$row_num+1][$column] = "$cell:" . $comments_indexed[$number_to_letter_map[$column] . ($row_num + 1)];
            echo $number_to_letter_map[$column] . ($row_num + 1) . ":";
            echo $risk_master[$row_num+1][$column] . ":";
            echo $comments_indexed[$cell . ($row_num + 1)] . PHP_EOL;
        }
        //echo $number_to_letter_map[$column] . ($row_num + 1) . PHP_EOL;
        
        
    }
}


$fp = fopen('risk_master_w_comments.csv', 'w');

foreach ($risk_master_w_comments as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);