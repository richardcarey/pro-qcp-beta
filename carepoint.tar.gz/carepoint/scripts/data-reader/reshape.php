<?php

use phpseclib\Crypt\RC2;

chdir(__DIR__);

require_once 'Models.php';

$modules = csv_to_array('modules.csv');
$assessments = csv_to_array('assesmetns.csv');
$risks =  csv_to_array('risk_master.csv');
$qcps =  csv_to_array('qcps.csv');
$risk_qcps =  csv_to_array('risk_qcps.csv');
$replacement_patterns =  csv_to_array('replacement_patterns.csv');
$comments = json_decode(file_get_contents('comments_indexed.json'), TRUE);

// remove headers
unset($modules[0]);

$modules_reshaped = [];

foreach ($modules as $key => $module) {
    $Module = new Module($module);

    $modules_reshaped[$Module->part_number] = $Module;
}

file_put_contents('data/modules.json', json_encode($modules_reshaped, JSON_PRETTY_PRINT));

$assessments_transposed = [];

$assessments_transposed = flipDiagonally($assessments);

/*
$fp = fopen('assessments_transposed.csv', 'w');

foreach ($assessments_transposed as $fields) {
    fputcsv($fp, $fields);
}

fclose($fp);
*/

// assesments

$assessments_reshaped = [];

foreach ($assessments_transposed as $key => $assessment) {
    $Assessment = new Assessment($assessment);
    $Assessment->setReplacements($replacement_patterns);
    $assessments_reshaped[$Assessment->assessment_id] = $Assessment;
}

file_put_contents('data/assessments.json', json_encode($assessments_reshaped, JSON_PRETTY_PRINT));


//risks 


$risks_reshaped = [];
$assessment_to_risk = [];

foreach ($risks as $key => $risk) {
    $Risk = new Risk($risk, $key);
    if(is_numeric($Risk->Index) && ($Risk->Index % 1000) != 0 ){
        $risks_reshaped[$Risk->Index] = $Risk;
        $assessment_id = 0;
        foreach ($risk as $_column => $enabled) {
            if($_column > 7){
                $risk_Index = $Risk->Index;
                $assessment_id = $_column + 2;
                $AssessmentToRisk = new AssessmentToRisk();
                $AssessmentToRisk->assesment_id = $assessment_id;
                $AssessmentToRisk->risk_Index = $risk_Index;
                $AssessmentToRisk->enabled = $enabled;
                if(strtolower(trim($enabled)) == 'x'){
                    $assessment_to_risk[$AssessmentToRisk->assesment_id][$AssessmentToRisk->risk_Index] = $AssessmentToRisk;
                }
                
            }
        }
    }
    
}

file_put_contents('data/risks.json', json_encode($risks_reshaped, JSON_PRETTY_PRINT));
file_put_contents('data/assessment_to_risk.json', json_encode($assessment_to_risk, JSON_PRETTY_PRINT));


$assessments_with_risks = [];

foreach ($assessments_reshaped as $_key => $assessment) {
  $replacement_values[$_key] = $assessment->string_token_replacement_values;
    if(isset($assessment_to_risk[$_key]))
    foreach ($assessment_to_risk[$_key] as $__key => $__a2r) {
        $risks_reshaped[$__key];

        
        $__risk = (array) $risks_reshaped[$__key];
        //print_r($__risk);
        $__risk['RISK_Statement'] = str_replace(
            array_keys($assessment->string_token_replacement_values), 
            array_values($assessment->string_token_replacement_values), 
            $__risk['RISK_Statement']
        );
        $__risk['Risk_abbreviated_terms'] = str_replace(
          array_keys($assessment->string_token_replacement_values), 
          array_values($assessment->string_token_replacement_values), 
          $__risk['Risk_abbreviated_terms']
      );
        $_risks_reshaped[$__key] = $__risk;
        

        $assessment->risks[] = $_risks_reshaped[$__key];
    }
    $assessments_with_risks[] = $assessment;
}
$comments = new Comments($assessments_with_risks, $comments);
$comments->mapCommentsToRisks();

$assessments_with_risks = $comments->risk_assessment;

file_put_contents('data/assessments_with_risks.json', json_encode($assessments_with_risks, JSON_PRETTY_PRINT));




//qcps

$qcps_reshaped = [];

foreach ($qcps as $qcp_key => $qcp) {
    $QCP = new QCP($qcp);
    if(is_numeric($QCP->QCP_ID) ){
        $qcps_reshaped[$QCP->QCP_ID] = $QCP;
    }
}

file_put_contents('data/qcps.json', json_encode($qcps_reshaped, JSON_PRETTY_PRINT));

// risk to qcp pairing 


$risk_qcps_reshaped = [];

$risk_qcps_reshaped = flipDiagonally($risk_qcps);






$risk_to_qcp = [];

foreach ($risk_qcps as $key => $risk) {
    $RiskToQCP = new RiskToQCP();
    foreach ($risk as $_column => $enabled) {
        if($_column > 3){
            $risk_Index = $risk[1];
            $qcp_id = $risk_qcps[4][$_column]; //$qcp_lookup[$_column];
            $RiskToQCP = new RiskToQCP();
            $RiskToQCP->QCP_ID = $qcp_id;
            $RiskToQCP->risk_Index = $risk_Index;
            $RiskToQCP->enabled = $enabled;
            if(strtolower(trim($enabled)) == 'x'){
                $risk_to_qcp[$RiskToQCP->risk_Index][$RiskToQCP->QCP_ID] = $qcps_reshaped[$RiskToQCP->QCP_ID];
                $risk_to_qcp[$RiskToQCP->risk_Index][$RiskToQCP->QCP_ID]->risk_Index = $risk_Index;
            }
            
        }
    }
}





// put all together

$full_db = [];
$c = 0;
// foreach ($assessments_with_risks as $assessment_key => &$assessment) {
//   foreach ($assessment->risks as $key => &$risk) {
//       if(isset($risk_to_qcp[$risk['Index']])){
//           foreach ($risk_to_qcp[$risk['Index']] as $key => $value) {
//             // replace QCP placeholders with real values
//             if (isset($replacement_values[$assessment_key])) {
//               $value->Action = str_replace(
//                 array_keys($replacement_values[$assessment_key]), 
//                 array_values($replacement_values[$assessment_key]), 
//                 $value->Action
//               );
//               $value->Frequency = str_replace(
//                 array_keys($replacement_values[$assessment_key]), 
//                 array_values($replacement_values[$assessment_key]), 
//                 $value->Frequency
//               );
//               $value->Criteria = str_replace(
//                 array_keys($replacement_values[$assessment_key]), 
//                 array_values($replacement_values[$assessment_key]), 
//                 $value->Criteria
//               );
//             }

//              // $risk->qcps[] = $qcps_reshaped[$value->QCP_ID];
//               //echo $c . PHP_EOL;
//               $c = $c + 1;
//           }
//       }
//           //$risk->qcps = $risk_to_qcp[$risk->Index];
//   }
// }

file_put_contents('data/risk_to_qcp.json', json_encode($risk_to_qcp, JSON_PRETTY_PRINT));
// $full_db = $assessments_with_risks;
// foreach ($full_db as $key => $item) {
//     file_put_contents("data/final/$key.json", json_encode($item, JSON_PRETTY_PRINT));
// }
//file_put_contents('data/full_db.json', json_encode($full_db, JSON_PRETTY_PRINT));